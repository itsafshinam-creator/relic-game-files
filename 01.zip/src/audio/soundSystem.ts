/**
 * Audio and Theme Music Engine for Lego Fantasy RPG
 * Features real MP3 playback with smooth crossfading, adaptive context switching,
 * low-volume defaults, procedural fallback synthesis, and complete audio controls.
 */

export type BgmThemeId = 'soft_piano' | 'adventure' | 'battle' | 'custom' | 'menu';

export interface ThemeTrackInfo {
  id: BgmThemeId;
  title: string;
  subtitle: string;
  description: string;
  primaryContext: string;
  filePaths: string[];
}

export const THEME_TRACKS: Record<BgmThemeId, ThemeTrackInfo> = {
  soft_piano: {
    id: 'soft_piano',
    title: 'Soft Piano Warmth',
    subtitle: 'Safe Haven & Village Theme',
    description: 'Gentle, warm acoustic piano melodies for peaceful villages, dialogues, and campfires',
    primaryContext: 'Village, Campfire, NPC Dialogue, Character Studio',
    filePaths: ['/audio/Soft Piano Warmth.mp3', '/audio/soft-piano-warmth.mp3'],
  },
  adventure: {
    id: 'adventure',
    title: 'Adventure Theme',
    subtitle: 'Overworld Exploration Theme',
    description: 'Heroic, uplifting fantasy fanfare for wandering open plains, forests, and ruins',
    primaryContext: 'Overworld Roaming & Ruins Exploration',
    filePaths: ['/audio/Adventure Theme.mp3', '/audio/adventure-theme.mp3'],
  },
  battle: {
    id: 'battle',
    title: 'Adventure Theme (Battle)',
    subtitle: 'Combat & Danger Theme',
    description: 'Driving, high-energy battle theme for hostile mob encounters and dungeon guardians',
    primaryContext: 'Enemy Aggro, Hostile Skeletons & Boss Combat',
    filePaths: ['/audio/Adventure Theme (1).mp3', '/audio/adventure-theme-battle.mp3'],
  },
  menu: {
    id: 'menu',
    title: 'Relic Main Theme',
    subtitle: 'Launch & Main Menu Theme',
    description: 'Theme music for the launch screen and main menu',
    primaryContext: 'Launch Screen & Main Menu',
    filePaths: ['/audio/menu-theme.mp3'],
  },
  custom: {
    id: 'custom',
    title: 'Custom User Theme',
    subtitle: 'User Loaded Audio',
    description: 'Custom uploaded audio track loaded by player',
    primaryContext: 'User Preference',
    filePaths: [],
  },
};

export interface AudioState {
  currentTheme: BgmThemeId;
  isPlaying: boolean;
  isMuted: boolean;
  musicVolume: number;
  sfxVolume: number;
  masterVolume: number;
  isAdaptive: boolean;
  contextMode: 'village' | 'exploration' | 'combat';
}

class SoundSystem {
  private ctx: AudioContext | null = null;
  private sfxGain: GainNode | null = null;
  private bgmGain: GainNode | null = null;

  // Volumes (Default: gentle low volume as requested "با صدای کم")
  private masterVolume: number = 0.85;
  private musicVolume: number = 0.15; // 15% gentle background volume
  private sfxVolume: number = 0.32;   // 32% crisp sound effects volume
  private isMuted: boolean = false;

  // Theme Management
  private currentTheme: BgmThemeId = 'adventure';
  private isPlaying: boolean = false;
  private isAdaptive: boolean = true;
  private activeContext: 'village' | 'exploration' | 'combat' = 'exploration';
  private combatCooldownTimer: any = null;

  // HTMLAudio Elements for crossfading
  private currentAudio: HTMLAudioElement | null = null;
  private nextAudio: HTMLAudioElement | null = null;
  private crossfadeInterval: any = null;

  // Custom audio blobs
  private customAudioUrl: string | null = null;

  // State change listeners
  private stateListeners: Set<(state: AudioState) => void> = new Set();

  constructor() {
    // Resume audio context & unlock HTML5 Audio on user interaction
    const unlockAudio = () => {
      this.initContext();
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      window.removeEventListener('pointerdown', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('pointerdown', unlockAudio, { once: true });
      window.addEventListener('keydown', unlockAudio, { once: true });
    }
  }

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.value = this.isMuted ? 0 : this.sfxVolume * this.masterVolume;
        this.sfxGain.connect(this.ctx.destination);

        this.bgmGain = this.ctx.createGain();
        this.bgmGain.gain.value = this.isMuted ? 0 : this.musicVolume * this.masterVolume;
        this.bgmGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getState(): AudioState {
    return {
      currentTheme: this.currentTheme,
      isPlaying: this.isPlaying,
      isMuted: this.isMuted,
      musicVolume: this.musicVolume,
      sfxVolume: this.sfxVolume,
      masterVolume: this.masterVolume,
      isAdaptive: this.isAdaptive,
      contextMode: this.activeContext,
    };
  }

  public subscribe(listener: (state: AudioState) => void): () => void {
    this.stateListeners.add(listener);
    listener(this.getState());
    return () => {
      this.stateListeners.delete(listener);
    };
  }

  private notify() {
    const s = this.getState();
    this.stateListeners.forEach((fn) => {
      try {
        fn(s);
      } catch (err) {
        console.error('Audio state listener error:', err);
      }
    });
  }

  // --- Volume Controls ---

  public setMute(mute: boolean) {
    this.isMuted = mute;
    if (this.currentAudio) {
      this.currentAudio.muted = mute;
    }
    if (this.nextAudio) {
      this.nextAudio.muted = mute;
    }
    if (this.sfxGain) {
      this.sfxGain.gain.value = mute ? 0 : this.sfxVolume * this.masterVolume;
    }
    this.notify();
  }

  public setMusicVolume(vol: number) {
    this.musicVolume = Math.max(0, Math.min(1, vol));
    const effectiveVol = this.isMuted ? 0 : this.musicVolume * this.masterVolume;
    if (this.currentAudio) {
      this.currentAudio.volume = effectiveVol;
    }
    if (this.bgmGain) {
      this.bgmGain.gain.value = effectiveVol;
    }
    this.notify();
  }

  public setSfxVolume(vol: number) {
    this.sfxVolume = Math.max(0, Math.min(1, vol));
    if (this.sfxGain) {
      this.sfxGain.gain.value = this.isMuted ? 0 : this.sfxVolume * this.masterVolume;
    }
    this.notify();
  }

  public setMasterVolume(vol: number) {
    this.masterVolume = Math.max(0, Math.min(1, vol));
    this.setMusicVolume(this.musicVolume);
    this.setSfxVolume(this.sfxVolume);
  }

  public setAdaptiveMusic(enabled: boolean) {
    this.isAdaptive = enabled;
    this.notify();
  }

  // --- Background Music Management & Crossfading ---

  private menuLock: boolean = false;

  /** Launch / main-menu music: plays the menu theme and blocks adaptive switching. */
  public startMenuMusic() {
    this.menuLock = true;
    this.isPlaying = true;
    this.currentTheme = 'menu';
    this.playTrack('menu', false);
    this.notify();
  }

  /** Leaving the menu: crossfade into the overworld theme and let adaptive music take over. */
  public endMenuMusic() {
    if (!this.menuLock) return;
    this.menuLock = false;
    this.activeContext = 'exploration' as any;
    this.isPlaying = true;
    this.currentTheme = 'menu';
    this.setTheme('adventure', true);
  }

  public toggleBGM(enable?: boolean) {
    const targetState = enable !== undefined ? enable : !this.isPlaying;
    if (targetState === this.isPlaying) return;

    this.isPlaying = targetState;
    if (this.isPlaying) {
      this.playTrack(this.currentTheme, false);
    } else {
      this.stopBGM(true);
    }
    this.notify();
  }

  public setTheme(theme: BgmThemeId, crossfade: boolean = true) {
    if (this.currentTheme === theme && this.isPlaying) return;
    this.currentTheme = theme;
    if (this.isPlaying) {
      this.playTrack(theme, crossfade);
    }
    this.notify();
  }

  public setCustomAudio(file: File) {
    if (this.customAudioUrl) {
      URL.revokeObjectURL(this.customAudioUrl);
    }
    this.customAudioUrl = URL.createObjectURL(file);
    THEME_TRACKS.custom.title = file.name.replace(/\.[^/.]+$/, '');
    this.setTheme('custom', true);
  }

  private getAudioSrc(theme: BgmThemeId): string | null {
    if (theme === 'custom') {
      return this.customAudioUrl;
    }
    const info = THEME_TRACKS[theme];
    return info && info.filePaths.length > 0 ? info.filePaths[0] : null;
  }

  private playTrack(theme: BgmThemeId, crossfade: boolean) {
    const targetSrc = this.getAudioSrc(theme);
    if (!targetSrc) return;

    const effectiveTargetVol = this.isMuted ? 0 : this.musicVolume * this.masterVolume;

    const newAudio = new Audio();
    newAudio.src = targetSrc;
    newAudio.loop = true;
    newAudio.muted = this.isMuted;
    newAudio.volume = crossfade ? 0.001 : effectiveTargetVol;

    // Handle alternate filename fallback if error occurs
    newAudio.onerror = () => {
      const info = THEME_TRACKS[theme];
      if (info && info.filePaths.length > 1 && newAudio.src !== info.filePaths[1]) {
        newAudio.src = info.filePaths[1];
        newAudio.play().catch(() => {});
      }
    };

    const playPromise = newAudio.play();
    if (playPromise) {
      playPromise.catch(() => {
        // Autoplay policy: retry on the first user gesture
        const retry = () => {
          window.removeEventListener('pointerdown', retry);
          window.removeEventListener('keydown', retry);
          if (newAudio.paused && newAudio.src) newAudio.play().catch(() => {});
        };
        window.addEventListener('pointerdown', retry);
        window.addEventListener('keydown', retry);
      });
    }

    if (!crossfade || !this.currentAudio) {
      if (this.currentAudio) {
        this.currentAudio.pause();
        this.currentAudio.src = '';
      }
      this.currentAudio = newAudio;
      this.currentAudio.volume = effectiveTargetVol;
      return;
    }

    // Smooth Crossfade over 1.2 seconds
    const oldAudio = this.currentAudio;
    this.nextAudio = newAudio;

    const steps = 24;
    const stepDuration = 1200 / steps;
    let step = 0;

    if (this.crossfadeInterval) clearInterval(this.crossfadeInterval);

    this.crossfadeInterval = setInterval(() => {
      step++;
      const progress = step / steps;
      if (oldAudio) {
        oldAudio.volume = Math.max(0, effectiveTargetVol * (1 - progress));
      }
      if (this.nextAudio) {
        this.nextAudio.volume = Math.min(effectiveTargetVol, effectiveTargetVol * progress);
      }

      if (step >= steps) {
        clearInterval(this.crossfadeInterval);
        this.crossfadeInterval = null;
        if (oldAudio) {
          oldAudio.pause();
          oldAudio.src = '';
        }
        this.currentAudio = this.nextAudio;
        this.nextAudio = null;
        if (this.currentAudio) {
          this.currentAudio.volume = effectiveTargetVol;
        }
      }
    }, stepDuration);
  }

  private stopBGM(fadeOut: boolean = true) {
    if (!fadeOut || !this.currentAudio) {
      if (this.currentAudio) {
        this.currentAudio.pause();
        this.currentAudio = null;
      }
      return;
    }

    const audioToStop = this.currentAudio;
    const initialVol = audioToStop.volume;
    let step = 0;
    const steps = 15;
    const interval = setInterval(() => {
      step++;
      audioToStop.volume = Math.max(0, initialVol * (1 - step / steps));
      if (step >= steps) {
        clearInterval(interval);
        audioToStop.pause();
        if (this.currentAudio === audioToStop) {
          this.currentAudio = null;
        }
      }
    }, 40);
  }

  // --- Dynamic Adaptive Music Engine ---

  public updateGameContext(context: { inCombat: boolean; nearVillage: boolean; inDialogue: boolean }) {
    if (this.menuLock || !this.isAdaptive || !this.isPlaying) return;

    let targetContext: 'village' | 'exploration' | 'combat' = 'exploration';
    let targetTheme: BgmThemeId = 'adventure';

    if (context.inCombat) {
      targetContext = 'combat';
      targetTheme = 'battle';
      // Reset combat cooldown
      if (this.combatCooldownTimer) {
        clearTimeout(this.combatCooldownTimer);
        this.combatCooldownTimer = null;
      }
    } else if (context.inDialogue || context.nearVillage) {
      targetContext = 'village';
      targetTheme = 'soft_piano';
    } else {
      targetContext = 'exploration';
      targetTheme = 'adventure';
    }

    if (this.activeContext === targetContext && this.currentTheme === targetTheme) {
      return;
    }

    // Debounce combat exit by 3 seconds to avoid abrupt music bouncing
    if (this.activeContext === 'combat' && targetContext !== 'combat') {
      if (!this.combatCooldownTimer) {
        this.combatCooldownTimer = setTimeout(() => {
          this.combatCooldownTimer = null;
          this.activeContext = targetContext;
          this.setTheme(targetTheme, true);
        }, 2800);
      }
      return;
    }

    this.activeContext = targetContext;
    this.setTheme(targetTheme, true);
  }

  // --- SFX & SPARKLE SOUND EFFECTS ---

  /**
   * Authentic Coin Collecting Sparkle
   * Uses real MP3 with instant HTML5 Audio + Web Audio synthesizer fallback!
   */
  public playCoinSparkle() {
    this.playCoinPickup();
  }

  public playCoinPickup() {
    if (this.isMuted) return;

    // 1. Play real sparkle audio file
    const sparkleAudio = new Audio();
    sparkleAudio.src = '/audio/Coin Collecting Sparkle.mp3';
    sparkleAudio.volume = Math.min(1, this.sfxVolume * this.masterVolume * 1.1);
    sparkleAudio.play().catch(() => {
      // Fallback to high-frequency crystalline chime synthesizer
      this.playSyntheticSparkle();
    });
  }

  private playSyntheticSparkle() {
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const freqs = [587.33, 739.99, 880.0, 1108.73, 1174.66, 1479.98, 1760.0, 2349.32]; // D5 to D7 arpeggio
    freqs.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      const start = now + idx * 0.042;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);

      gain.gain.setValueAtTime(0.25, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(start);
      osc.stop(start + 0.36);
    });
  }

  // ---------------------------------------------------------------
  // Footsteps: a short noise "scuff" + a low heel thump, tuned per surface
  // ---------------------------------------------------------------
  private noiseBuffer: AudioBuffer | null = null;

  private getNoiseBuffer(): AudioBuffer | null {
    if (!this.ctx) return null;
    if (!this.noiseBuffer) {
      const len = Math.floor(this.ctx.sampleRate * 0.6);
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBuffer = buf;
    }
    return this.noiseBuffer;
  }

  private noiseBurst(opts: {
    type: BiquadFilterType;
    freq: number;
    q: number;
    dur: number;
    gain: number;
    delay?: number;
    rate?: number;
  }) {
    const ctx = this.ctx;
    const buf = this.getNoiseBuffer();
    if (!ctx || !buf || !this.sfxGain) return;
    const t0 = ctx.currentTime + (opts.delay ?? 0);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = opts.rate ?? 1;
    const filt = ctx.createBiquadFilter();
    filt.type = opts.type;
    filt.frequency.value = opts.freq;
    filt.Q.value = opts.q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(opts.gain, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0008, t0 + opts.dur);
    src.connect(filt);
    filt.connect(g);
    g.connect(this.sfxGain);
    src.start(t0, Math.random() * 0.4, opts.dur + 0.03);
  }

  private thump(freq: number, dur: number, gain: number, delay = 0) {
    const ctx = this.ctx;
    if (!ctx || !this.sfxGain) return;
    const t0 = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(30, freq * 0.45), t0 + dur);
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0008, t0 + dur);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  public playFootstep(surface: 'grass' | 'stone' | 'wood' | 'water' = 'grass', sprint = false, foot = 0) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const v = (sprint ? 1.2 : 0.9) * (0.9 + Math.random() * 0.2);
    const pitch = foot % 2 === 0 ? 1 : 1.08; // left / right foot differ slightly
    const r = Math.random();

    switch (surface) {
      case 'stone':
        this.noiseBurst({ type: 'bandpass', freq: (2100 + r * 700) * pitch, q: 1.3, dur: 0.07, gain: 1.1 * v });
        this.noiseBurst({ type: 'lowpass', freq: 700, q: 0.7, dur: 0.1, gain: 0.5 * v });
        this.thump(130 * pitch, 0.08, 0.5 * v);
        break;
      case 'wood':
        this.noiseBurst({ type: 'bandpass', freq: (750 + r * 150) * pitch, q: 2.4, dur: 0.1, gain: 0.9 * v });
        this.thump(170 * pitch, 0.12, 0.65 * v);
        this.thump(95 * pitch, 0.14, 0.4 * v, 0.01);
        break;
      case 'water':
        this.noiseBurst({ type: 'lowpass', freq: 1900, q: 0.6, dur: 0.22, gain: 1.0 * v, rate: 0.9 });
        this.noiseBurst({ type: 'bandpass', freq: 650 + r * 200, q: 1.2, dur: 0.18, gain: 0.7 * v, delay: 0.03 });
        break;
      default: // grass: soft swish + muffled heel
        this.noiseBurst({ type: 'lowpass', freq: (1000 + r * 350) * pitch, q: 0.7, dur: 0.12, gain: 0.95 * v });
        this.noiseBurst({ type: 'highpass', freq: 3500, q: 0.7, dur: 0.05, gain: 0.18 * v });
        this.thump(100 * pitch, 0.09, 0.45 * v);
    }
  }

  public playLanding(surface: 'grass' | 'stone' | 'wood' | 'water' = 'grass') {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;
    this.playFootstep(surface, true, 0);
    this.thump(80, 0.16, 0.7);
  }

  // ---------------------------------------------------------------
  // NPC speech: Clash-of-Clans style babble. Every call is one short
  // "syllable" (formant-filtered voice with a pitch glide) so the
  // dialogue typewriter can fire them while the text is being revealed.
  // ---------------------------------------------------------------
  public lastSpeech = { time: 0, voice: '' };

  private static VOICES: Record<
    string,
    { base: number; range: number; formant: number; wave: OscillatorType; vibrato: number; gain: number }
  > = {
    mara: { base: 330, range: 0.22, formant: 1.18, wave: 'triangle', vibrato: 5.5, gain: 1.5 },
    toren: { base: 108, range: 0.16, formant: 0.82, wave: 'sawtooth', vibrato: 0, gain: 1.35 },
    merchant: { base: 205, range: 0.25, formant: 1.0, wave: 'sawtooth', vibrato: 4, gain: 1.35 },
    guard: { base: 150, range: 0.12, formant: 0.9, wave: 'square', vibrato: 0, gain: 1.1 },
  };
  private static VOWELS: [number, number][] = [
    [800, 1150], // a
    [530, 1850], // e
    [300, 2300], // i
    [500, 900], // o
    [330, 800], // u
  ];

  public playNPCSyllable(voice: string, contour: 'fall' | 'rise' | 'flat' = 'fall') {
    if (this.isMuted) return;
    this.initContext();
    const ctx = this.ctx;
    if (!ctx || !this.sfxGain) return;

    const prof = SoundSystem.VOICES[voice] ?? SoundSystem.VOICES.merchant;
    const now = ctx.currentTime;
    const dur = 0.07 + Math.random() * 0.06;
    const base = prof.base * (1 + (Math.random() - 0.5) * prof.range * 2);
    const [f1, f2] = SoundSystem.VOWELS[Math.floor(Math.random() * SoundSystem.VOWELS.length)];

    const osc = ctx.createOscillator();
    osc.type = prof.wave;
    const endMul = contour === 'rise' ? 1.22 : contour === 'fall' ? 0.84 : 1;
    osc.frequency.setValueAtTime(base * 0.94, now);
    osc.frequency.linearRampToValueAtTime(base * 1.06, now + dur * 0.35);
    osc.frequency.linearRampToValueAtTime(base * endMul, now + dur);

    if (prof.vibrato > 0) {
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.value = prof.vibrato;
      lfoGain.gain.value = base * 0.025;
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);
      lfo.start(now);
      lfo.stop(now + dur + 0.02);
    }

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, now);
    env.gain.linearRampToValueAtTime(prof.gain, now + 0.012);
    env.gain.exponentialRampToValueAtTime(0.0008, now + dur);

    [
      [f1 * prof.formant, 1.0],
      [f2 * prof.formant, 0.6],
    ].forEach(([freq, level]) => {
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = freq;
      bp.Q.value = 5;
      const lg = ctx.createGain();
      lg.gain.value = level;
      osc.connect(bp);
      bp.connect(lg);
      lg.connect(env);
    });
    env.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + dur + 0.03);

    // tiny consonant "puff" at the start of some syllables
    if (Math.random() < 0.55) {
      this.noiseBurst({ type: 'highpass', freq: 1800, q: 0.7, dur: 0.025, gain: 0.35 });
    }

    this.lastSpeech = { time: performance.now(), voice };
  }

  public playSwordSlash() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const bufferSize = this.ctx.sampleRate * 0.22;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    const now = this.ctx.currentTime;
    filter.frequency.setValueAtTime(800, now);
    filter.frequency.exponentialRampToValueAtTime(3200, now + 0.08);
    filter.frequency.exponentialRampToValueAtTime(400, now + 0.2);
    filter.Q.value = 3.0;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.22);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(now);
  }

  public playBowShoot() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(420, now);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.12);

    gain.gain.setValueAtTime(0.4, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playArrowHit() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(60, now + 0.1);

    gain.gain.setValueAtTime(0.5, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.1);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  public playChestOpen() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const freqs = [392, 523.25, 659.25, 783.99, 1046.5];
    freqs.forEach((f, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      const startTime = now + i * 0.07;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, startTime);

      gain.gain.setValueAtTime(0.25, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain!);
      osc.start(startTime);
      osc.stop(startTime + 0.35);
    });

    // Also trigger sparkle jingle for opening treasure chest!
    setTimeout(() => {
      this.playCoinSparkle();
    }, 180);
  }

  public playEnemyHit() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(50, now + 0.15);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playDodgeRoll() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.sfxGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.2);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.linearRampToValueAtTime(0.01, now + 0.2);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.2);
  }
}

export const sounds = new SoundSystem();
