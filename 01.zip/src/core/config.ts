export const GAME_CONFIG = {
  TITLE: 'RELIC: The Lost World',
  VERSION: '2.0.0',

  // Atmospheric Fog & Sky Settings (Deep, thick volumetric fog filling the world)
  ENVIRONMENT: {
    SKY_COLOR: '#151D2A', // Deep atmospheric twilight slate
    FOG_COLOR: '#151D2A', // Seamlessly conceals horizons and wraps world
    FOG_DENSITY: 0.042,   // Dense, rich atmospheric fog filling space
    FOG_NEAR: 4,
    FOG_FAR: 38,
    MIST_PARTICLE_COUNT: 160,
    MIST_HEIGHT: 3.5,
  },

  // Graphics & Rendering
  GRAPHICS: {
    SHADOW_MAP_SIZE: 2048,
    SHADOW_BIAS: -0.0004,
    ANTIALIAS: true,
    TONE_MAPPING_EXPOSURE: 1.15,
  },

  // Responsive Player Movement & Controls
  CONTROLS: {
    ACCELERATION: 45.0,
    DECELERATION: 16.0,
    WALK_SPEED: 6.2,
    SPRINT_SPEED: 10.5,
    ROTATION_SPEED: 15.0,
    JUMP_IMPULSE: 7.8,
    GRAVITY: 22.0,
    ROLL_IMPULSE: 12.0,
    ROLL_STAMINA_COST: 15,
    STAMINA_REGEN: 14.0,

    // Mouse & Camera Orbit
    MOUSE_SENSITIVITY: 0.0035,
    TOUCH_SENSITIVITY: 0.005,
    CAMERA_MIN_DISTANCE: 2.2,
    CAMERA_MAX_DISTANCE: 9.0,
    CAMERA_DEFAULT_DISTANCE: 4.8,
    CAMERA_MIN_PITCH: 0.05,
    CAMERA_MAX_PITCH: 1.25,
    CAMERA_DAMPING: 0.07, // lower = smoother camera
    CAMERA_FOLLOW_SPEED: 2.6, // auto-follow swing speed (higher = snappier)
    CAMERA_RECENTER_DELAY: 3.0, // seconds after manual camera move before returning to default
    CAMERA_RECENTER_SPEED: 1.8, // how fast it returns to default angle
    CAMERA_DEFAULT_PITCH: 0.35,
  },

  // Combat Mechanics
  COMBAT: {
    SWORD_DAMAGE_MIN: 28,
    SWORD_DAMAGE_MAX: 44,
    SWORD_RANGE: 2.2,
    ARROW_SPEED: 34.0,
    ARROW_DAMAGE_MIN: 38,
    ARROW_DAMAGE_MAX: 52,
    MAX_ARROWS: 40,
    COMBO_TIMEOUT: 2200,
  },

  // World layout: the Base camp is a SAFE hub (no enemies). All combat lives in Stage 1,
  // which begins on the far side of the gate.
  WORLD: {
    GATE_X: -24,
    GATE_Z: -32,
    /** Walking north of this line (any x) always counts as being in Stage 1. */
    STAGE1_LINE_Z: -36.5,
    /** Enemies can never walk south of this line, so they can't follow the player into the Base. */
    ENEMY_LIMIT_Z: -36,
  },

  // Audio Volumes
  AUDIO: {
    SFX_VOLUME: 0.4,
    BGM_VOLUME: 0.15,
  },
};
