import * as THREE from 'three';
import { GAME_CONFIG } from '../core/config';

const CAM_MAX_DIALOGUE = 6.5;

export class ThirdPersonCameraController {
  public camera: THREE.PerspectiveCamera;
  private currentYaw: number = 0;
  private currentPitch: number = 0.35;
  private targetYaw: number = 0;
  private targetPitch: number = 0.35;
  private currentDistance: number = GAME_CONFIG.CONTROLS.CAMERA_DEFAULT_DISTANCE;
  private targetDistance: number = GAME_CONFIG.CONTROLS.CAMERA_DEFAULT_DISTANCE;

  private manualTimer: number = 0;
  private needsRecenter: boolean = false;

  // Dialogue cinematic framing
  private dialogueNPCPos: THREE.Vector3 | null = null;
  private dialogueBlend: number = 0; // 0 = normal camera, 1 = full dialogue shot
  private smoothFocus: THREE.Vector3 = new THREE.Vector3();
  private focusInit: boolean = false;
  private dialogueSide: number = 0;

  constructor(camera: THREE.PerspectiveCamera) {
    this.camera = camera;
  }

  /** Frame the hero and the NPC together while talking; pass null to leave dialogue. */
  public setDialogueTarget(npcPos: THREE.Vector3 | null) {
    if (npcPos) {
      if (!this.dialogueNPCPos) this.dialogueSide = 0; // re-pick side on new conversation
      this.dialogueNPCPos = npcPos.clone();
    } else if (this.dialogueNPCPos) {
      this.dialogueNPCPos = null;
      this.manualTimer = 0;
      this.needsRecenter = true; // swing back behind the hero afterwards
    }
  }

  public handleInput(lookX: number, lookY: number, zoomDelta: number) {
    if (this.dialogueNPCPos) return; // cinematic dialogue shot owns the camera
    // Player is manually orbiting: pause auto-follow briefly
    if (Math.abs(lookX) > 0.0005 || Math.abs(lookY) > 0.0005 || Math.abs(zoomDelta) > 0.0005) {
      this.manualTimer = GAME_CONFIG.CONTROLS.CAMERA_RECENTER_DELAY;
      this.needsRecenter = true;
    }
    this.targetYaw -= lookX;
    this.targetPitch = Math.max(
      GAME_CONFIG.CONTROLS.CAMERA_MIN_PITCH,
      Math.min(GAME_CONFIG.CONTROLS.CAMERA_MAX_PITCH, this.targetPitch + lookY)
    );

    this.targetDistance = Math.max(
      GAME_CONFIG.CONTROLS.CAMERA_MIN_DISTANCE,
      Math.min(GAME_CONFIG.CONTROLS.CAMERA_MAX_DISTANCE, this.targetDistance + zoomDelta)
    );
  }

  /**
   * Auto-follow: smoothly swing the camera behind the character's heading
   * while the character is moving, so the camera always comes with us.
   */
  public autoFollow(heading: number, isMoving: boolean, movingBackward: boolean, delta: number) {
    if (this.dialogueNPCPos) return;
    // Wait a few seconds after the player last moved the camera by hand
    this.manualTimer = Math.max(0, this.manualTimer - delta);
    if (this.manualTimer > 0) return;

    const C = GAME_CONFIG.CONTROLS;
    const desired = heading + Math.PI; // camera sits opposite to facing direction
    const wrap = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));

    // Follow while moving (not when walking backwards towards the camera)
    if (isMoving && !movingBackward) {
      this.targetYaw += wrap(desired - this.targetYaw) * (1 - Math.exp(-C.CAMERA_FOLLOW_SPEED * delta));
    }

    // After manual control: ease back to the default angle, pitch and distance
    if (this.needsRecenter) {
      const r = 1 - Math.exp(-C.CAMERA_RECENTER_SPEED * delta);
      if (!movingBackward) this.targetYaw += wrap(desired - this.targetYaw) * r;
      this.targetPitch += (C.CAMERA_DEFAULT_PITCH - this.targetPitch) * r;
      this.targetDistance += (C.CAMERA_DEFAULT_DISTANCE - this.targetDistance) * r;
      if (
        Math.abs(wrap(desired - this.targetYaw)) < 0.01 &&
        Math.abs(C.CAMERA_DEFAULT_PITCH - this.targetPitch) < 0.01 &&
        Math.abs(C.CAMERA_DEFAULT_DISTANCE - this.targetDistance) < 0.02
      ) {
        this.needsRecenter = false;
      }
    }
  }

  public update(targetPos: THREE.Vector3, delta: number) {
    let focusTarget = targetPos.clone().add(new THREE.Vector3(0, 1.35, 0));
    this.dialogueBlend += ((this.dialogueNPCPos ? 1 : 0) - this.dialogueBlend) * Math.min(1, 3.5 * delta);

    if (this.dialogueNPCPos) {
      const dx = this.dialogueNPCPos.x - targetPos.x;
      const dz = this.dialogueNPCPos.z - targetPos.z;
      const sep = Math.max(0.5, Math.hypot(dx, dz));
      const nx = dx / sep, nz = dz / sep;

      // Camera sits to the side of the conversation line so both faces/bodies are visible,
      // slightly pulled back over the hero's shoulder.
      if (this.dialogueSide === 0) {
        const camDirX = Math.sin(this.targetYaw), camDirZ = Math.cos(this.targetYaw);
        this.dialogueSide = (-nz * camDirX + nx * camDirZ) >= 0 ? 1 : -1;
      }
      const s = this.dialogueSide;
      const px = -nz * s, pz = nx * s; // perpendicular
      const ox = px * 0.92 - nx * 0.4, oz = pz * 0.92 - nz * 0.4;
      const desiredYaw = Math.atan2(ox, oz);
      let dy = desiredYaw - this.targetYaw;
      dy = Math.atan2(Math.sin(dy), Math.cos(dy));
      this.targetYaw += dy * Math.min(1, 4 * delta);
      this.targetPitch += (0.2 - this.targetPitch) * Math.min(1, 4 * delta);
      this.targetDistance += (Math.min(CAM_MAX_DIALOGUE, Math.max(3.4, sep * 1.5 + 2.2)) - this.targetDistance) * Math.min(1, 4 * delta);

      // Focus on the midpoint between hero and NPC (chest height)
      const mid = new THREE.Vector3((targetPos.x + this.dialogueNPCPos.x) / 2, targetPos.y + 1.25, (targetPos.z + this.dialogueNPCPos.z) / 2);
      focusTarget = focusTarget.lerp(mid, 1);
    }

    if (!this.focusInit) { this.smoothFocus.copy(focusTarget); this.focusInit = true; }
    else this.smoothFocus.lerp(focusTarget, Math.min(1, (this.dialogueNPCPos || this.dialogueBlend > 0.02 ? 5 : 30) * delta));

    // Smooth damp towards target yaw, pitch, and zoom
    const damping = Math.min(1, GAME_CONFIG.CONTROLS.CAMERA_DAMPING * 60 * delta);
    this.currentYaw += (this.targetYaw - this.currentYaw) * damping;
    this.currentPitch += (this.targetPitch - this.currentPitch) * damping;
    this.currentDistance += (this.targetDistance - this.currentDistance) * damping;

    const focusPoint = this.smoothFocus.clone();

    // Spherical coordinate offset
    const cosPitch = Math.cos(this.currentPitch);
    const sinPitch = Math.sin(this.currentPitch);
    const sinYaw = Math.sin(this.currentYaw);
    const cosYaw = Math.cos(this.currentYaw);

    const camX = focusPoint.x + sinYaw * cosPitch * this.currentDistance;
    const camY = Math.max(0.4, focusPoint.y + sinPitch * this.currentDistance); // Prevent dipping below ground
    const camZ = focusPoint.z + cosYaw * cosPitch * this.currentDistance;

    this.camera.position.set(camX, camY, camZ);
    this.camera.lookAt(focusPoint);
  }

  public getYaw(): number {
    return this.currentYaw;
  }
}
