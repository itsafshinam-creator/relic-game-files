import React, { useEffect, useRef } from 'react';

interface StageBannerProps {
  stage: number;
  first: boolean;
  onDone: () => void;
}

// Cinematic title card shown when the player walks through the gate into a stage.
export const StageBanner: React.FC<StageBannerProps> = ({ stage, first, onDone }) => {
  const doneRef = useRef(onDone);
  doneRef.current = onDone;
  useEffect(() => {
    const id = setTimeout(() => doneRef.current(), 3600);
    return () => clearTimeout(id);
  }, []);

  return (
    <div className="absolute inset-0 z-30 pointer-events-none flex items-center justify-center overflow-hidden">
      <style>{`
        @keyframes stageFlash { 0% { opacity: .85 } 100% { opacity: 0 } }
        @keyframes stageTitle { 0% { opacity: 0; transform: scale(1.12); letter-spacing: .5em }
          15% { opacity: 1 } 80% { opacity: 1 } 100% { opacity: 0; transform: scale(.98); letter-spacing: .18em } }
      `}</style>
      <div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, rgba(125,211,252,0.55), rgba(2,6,23,0.5) 70%)',
          animation: 'stageFlash 1.4s ease-out forwards',
        }}
      />
      <div className="text-center" style={{ animation: 'stageTitle 3.6s ease-out forwards', letterSpacing: '.18em' }}>
        <p className="text-cyan-200/90 text-xs sm:text-sm uppercase tracking-[0.5em] mb-2">
          {first ? 'The gate opens' : 'Back through the gate'}
        </p>
        <h2
          className="text-5xl sm:text-7xl font-extrabold text-white drop-shadow-[0_4px_24px_rgba(0,0,0,0.8)]"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          STAGE {stage}
        </h2>
        <div className="mx-auto mt-3 h-px w-48 bg-gradient-to-r from-transparent via-amber-300 to-transparent" />
      </div>
    </div>
  );
};
