import React, { useEffect, useRef } from 'react';

export interface MinimapData {
  player: { x: number; z: number; rotation: number };
  yaw: number;
  npcs: { x: number; z: number; type: string }[];
  enemies: { x: number; z: number; boss: boolean }[];
  resources: { x: number; z: number; type: string }[];
  gate: { x: number; z: number };
  zone: 'base' | 'stage1';
}

interface MinimapProps {
  getData: () => MinimapData | null;
  size?: number;
  /** World units visible from the centre to the edge of the map. */
  range?: number;
}

// Fixed landmarks of the base (static world layout).
const LANDMARKS: { x: number; z: number; label: string }[] = [
  { x: -6, z: 8, label: 'Camp' },
  { x: 20, z: -2, label: 'Forge' },
  { x: -20, z: -6, label: 'Outpost' },
  { x: 0, z: -32, label: 'Temple' },
];
const POND = { x: -18, z: 20, r: 6.5 };

const RESOURCE_COLORS: Record<string, string> = {
  wood: '#d97706',
  iron: '#cbd5e1',
  crystal: '#22d3ee',
  gold: '#facc15',
  relic_shard: '#7dd3fc',
};

/**
 * Circular, camera-rotating minimap drawn on a canvas.
 * Up on the map is always the direction the camera is looking.
 */
export const Minimap: React.FC<MinimapProps> = ({ getData, size = 168, range = 42 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const getDataRef = useRef(getData);
  getDataRef.current = getData;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const R = size / 2;
    const scale = (R - 6) / range; // pixels per world unit
    let raf = 0;

    const draw = () => {
      raf = requestAnimationFrame(draw);
      const d = getDataRef.current();
      if (!d) return;

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);

      const cos = Math.cos(d.yaw);
      const sin = Math.sin(d.yaw);
      // World offset -> minimap pixels (camera forward is "up").
      const project = (wx: number, wz: number) => {
        const dx = wx - d.player.x;
        const dz = wz - d.player.z;
        return { x: R + (dx * cos - dz * sin) * scale, y: R + (dx * sin + dz * cos) * scale };
      };

      ctx.save();
      ctx.beginPath();
      ctx.arc(R, R, R - 3, 0, Math.PI * 2);
      ctx.clip();

      // Ground tint
      const g = ctx.createRadialGradient(R, R, 4, R, R, R);
      g.addColorStop(0, 'rgba(34,64,52,0.55)');
      g.addColorStop(1, 'rgba(15,28,36,0.65)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, size, size);

      // Range rings
      ctx.strokeStyle = 'rgba(255,255,255,0.08)';
      ctx.lineWidth = 1;
      for (const f of [0.33, 0.66]) {
        ctx.beginPath();
        ctx.arc(R, R, (R - 6) * f, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Pond
      const pond = project(POND.x, POND.z);
      ctx.fillStyle = 'rgba(56,189,248,0.35)';
      ctx.beginPath();
      ctx.arc(pond.x, pond.y, POND.r * scale, 0, Math.PI * 2);
      ctx.fill();

      // Landmarks
      ctx.fillStyle = 'rgba(226,232,240,0.55)';
      for (const l of LANDMARKS) {
        const p = project(l.x, l.z);
        ctx.fillRect(p.x - 3, p.y - 3, 6, 6);
      }

      // Resources
      for (const r of d.resources) {
        const p = project(r.x, r.z);
        ctx.fillStyle = RESOURCE_COLORS[r.type] || '#e2e8f0';
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      // NPCs
      for (const n of d.npcs) {
        const p = project(n.x, n.z);
        ctx.fillStyle = '#4ade80';
        ctx.strokeStyle = 'rgba(0,0,0,0.5)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 3.6, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      // Enemies
      for (const e of d.enemies) {
        const p = project(e.x, e.z);
        ctx.fillStyle = e.boss ? '#f43f5e' : '#ef4444';
        ctx.beginPath();
        ctx.arc(p.x, p.y, e.boss ? 5 : 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();

      // Gate marker (pinned to the rim when off-screen)
      const gp = project(d.gate.x, d.gate.z);
      let gx = gp.x;
      let gy = gp.y;
      const gdx = gx - R;
      const gdy = gy - R;
      const gdist = Math.hypot(gdx, gdy);
      const maxR = R - 10;
      if (gdist > maxR) {
        gx = R + (gdx / gdist) * maxR;
        gy = R + (gdy / gdist) * maxR;
      }
      const pulse = 0.6 + 0.4 * Math.sin(performance.now() / 350);
      ctx.save();
      ctx.translate(gx, gy);
      ctx.fillStyle = `rgba(56,189,248,${0.25 * pulse})`;
      ctx.beginPath();
      ctx.arc(0, 0, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.fillStyle = '#e0f2fe';
      ctx.lineWidth = 1.6;
      // little arch icon
      ctx.beginPath();
      ctx.moveTo(-4, 4);
      ctx.lineTo(-4, -1);
      ctx.arc(0, -1, 4, Math.PI, 0);
      ctx.lineTo(4, 4);
      ctx.stroke();
      ctx.restore();

      // Player arrow (rotates relative to the camera)
      // facing direction (sin r, cos r) in world -> screen angle
      const fx = Math.sin(d.player.rotation);
      const fz = Math.cos(d.player.rotation);
      const sx = fx * cos - fz * sin;
      const sy = fx * sin + fz * cos;
      const ang = Math.atan2(sy, sx);
      ctx.save();
      ctx.translate(R, R);
      ctx.rotate(ang);
      ctx.fillStyle = '#fbbf24';
      ctx.strokeStyle = 'rgba(0,0,0,0.6)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(8, 0);
      ctx.lineTo(-5, 5);
      ctx.lineTo(-2.5, 0);
      ctx.lineTo(-5, -5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      // Cardinal letters on the rim (north = world -z)
      const north = project(d.player.x, d.player.z - 1000);
      const nAng = Math.atan2(north.y - R, north.x - R);
      const letters: [string, number, string][] = [
        ['N', 0, '#fbbf24'],
        ['E', Math.PI / 2, '#cbd5e1'],
        ['S', Math.PI, '#cbd5e1'],
        ['W', -Math.PI / 2, '#cbd5e1'],
      ];
      ctx.font = '600 10px ui-monospace, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      for (const [ch, off, col] of letters) {
        const a = nAng + off;
        ctx.fillStyle = col;
        ctx.fillText(ch, R + Math.cos(a) * (R - 9), R + Math.sin(a) * (R - 9));
      }
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [size, range]);

  return (
    <div
      className="relative rounded-full border border-white/25 bg-white/5 backdrop-blur-md shadow-[0_8px_30px_rgba(0,0,0,0.35)] ring-1 ring-amber-300/20"
      style={{ width: size, height: size }}
    >
      <canvas ref={canvasRef} style={{ width: size, height: size }} className="rounded-full" />
    </div>
  );
};
