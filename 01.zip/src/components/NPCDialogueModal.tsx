import React, { useCallback, useEffect, useRef, useState } from 'react';
import { NPCData } from '../types/relic';
import { X, Shield, Sparkles, ShoppingBag, ChevronDown } from 'lucide-react';
import { sounds } from '../audio/soundSystem';

interface NPCDialogueModalProps {
  npc: NPCData;
  onClose: () => void;
  onCompleteObjective?: (type: string) => void;
}

const CHAR_DELAY_MS = 32;

/**
 * Transparent in-world dialogue box. It floats over the live game view (no separate page,
 * no dimmed backdrop), reveals the text with a typewriter and plays a babble "voice"
 * (Clash-of-Clans style) for the NPC while the words appear.
 */
export const NPCDialogueModal: React.FC<NPCDialogueModalProps> = ({ npc, onClose, onCompleteObjective }) => {
  const [lineIdx, setLineIdx] = useState(0);
  const [shown, setShown] = useState(0);
  const line = npc.dialogue[lineIdx] ?? '';
  const done = shown >= line.length;
  const last = lineIdx >= npc.dialogue.length - 1;

  const stateRef = useRef({ done, last, lineLen: line.length });
  stateRef.current = { done, last, lineLen: line.length };

  // Music context while talking
  useEffect(() => {
    sounds.updateGameContext({ inCombat: false, nearVillage: true, inDialogue: true });
    return () => {
      sounds.updateGameContext({ inCombat: false, nearVillage: true, inDialogue: false });
    };
  }, []);

  // Typewriter + babble voice
  useEffect(() => {
    setShown(0);
    let n = 0;
    let letters = 0;
    const text = npc.dialogue[lineIdx] ?? '';
    const asksQuestion = text.trim().endsWith('?');
    const id = window.setInterval(() => {
      n++;
      setShown(n);
      const ch = text[n - 1];
      if (ch && /[\p{L}\p{N}]/u.test(ch)) {
        letters++;
        if (letters % 3 === 1) {
          const nearEnd = text.length - n < 9;
          sounds.playNPCSyllable(npc.type, asksQuestion && nearEnd ? 'rise' : 'fall');
        }
      }
      if (n >= text.length) window.clearInterval(id);
    }, CHAR_DELAY_MS);
    return () => window.clearInterval(id);
  }, [lineIdx, npc]);

  const advance = useCallback(() => {
    const st = stateRef.current;
    if (!st.done) setShown(st.lineLen); // finish the line instantly
    else if (!st.last) setLineIdx((i) => i + 1);
  }, []);

  // Keyboard: E / Enter / Space = continue (or farewell on the last line), Esc = close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const k = e.key.toLowerCase();
      if (k === 'escape') {
        e.preventDefault();
        onClose();
      } else if (k === 'e' || k === 'enter' || k === ' ') {
        e.preventDefault();
        const st = stateRef.current;
        if (st.done && st.last) onClose();
        else advance();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [advance, onClose]);

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 pointer-events-none flex justify-center p-3 md:p-6 select-none">
      <div className="pointer-events-auto w-full max-w-2xl rounded-2xl border border-white/20 bg-slate-950/35 backdrop-blur-sm shadow-[0_10px_40px_rgba(0,0,0,0.35)] text-white p-4 md:p-5 flex flex-col gap-3">
        {/* Speaker */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-400/20 border border-amber-300/50 flex items-center justify-center text-amber-300 shrink-0">
            {npc.type === 'toren' && <Shield className="w-5 h-5" />}
            {npc.type === 'mara' && <Sparkles className="w-5 h-5" />}
            {npc.type === 'merchant' && <ShoppingBag className="w-5 h-5" />}
            {npc.type === 'guard' && <Shield className="w-5 h-5" />}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-sm md:text-base font-bold font-serif text-amber-300 leading-tight drop-shadow">{npc.name}</h3>
            <p className="text-[11px] text-slate-200/80 leading-tight">{npc.title}</p>
          </div>
          <div className="flex items-center gap-1.5 mr-1">
            {npc.dialogue.map((_, i) => (
              <span
                key={i}
                className={`h-1.5 rounded-full transition-all ${
                  i === lineIdx ? 'w-4 bg-amber-300' : i < lineIdx ? 'w-1.5 bg-amber-300/60' : 'w-1.5 bg-white/25'
                }`}
              />
            ))}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-200/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close dialogue"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Typed line (the not-yet-shown part is invisible so the box never changes size) */}
        <div
          onClick={advance}
          className="min-h-[3.4rem] cursor-pointer text-sm md:text-[15px] leading-relaxed text-white [text-shadow:0_1px_6px_rgba(0,0,0,0.7)]"
        >
          <span>{line.slice(0, shown)}</span>
          <span className="opacity-0">{line.slice(shown)}</span>
        </div>

        {/* Footer: continue hint or action buttons */}
        <div className="flex items-center justify-end gap-2.5 min-h-[2.25rem]">
          {!done || !last ? (
            <button
              onClick={advance}
              className="flex items-center gap-1.5 text-[11px] text-amber-200/90 hover:text-amber-100"
            >
              <span className="hidden md:inline">Press</span>
              <kbd className="hidden md:inline px-1.5 py-0.5 rounded bg-white/15 font-mono text-[10px]">E</kbd>
              <span className="md:hidden">Tap</span>
              <ChevronDown className="w-3.5 h-3.5 animate-bounce" />
            </button>
          ) : (
            <>
              {npc.type === 'toren' && (
                <button
                  onClick={() => {
                    sounds.playChestOpen();
                    onCompleteObjective?.('forge_shield');
                    onClose();
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-400/90 hover:bg-amber-300 text-slate-950 font-bold text-xs transition-colors shadow"
                >
                  Forge Reinforced Shield
                </button>
              )}
              {npc.type === 'merchant' && (
                <button
                  onClick={() => {
                    sounds.playCoinPickup();
                    onCompleteObjective?.('buy_supplies');
                    onClose();
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500/90 hover:bg-emerald-400 text-white font-bold text-xs transition-colors shadow"
                >
                  Restock Arrows & Potions (10 gold)
                </button>
              )}
              <button
                onClick={onClose}
                className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-slate-100 font-semibold text-xs transition-colors"
              >
                Farewell
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
