import React, { useEffect, useState } from 'react';
import { Play, BookOpen, Music, Volume2, VolumeX } from 'lucide-react';

interface MainMenuProps {
  resumeMode: boolean;
  isMuted: boolean;
  onPlay: () => void;
  onHelp: () => void;
  onMusic: () => void;
  onToggleMute: () => void;
  /** Start the intro animations (false while the launch splash is still covering the menu). */
  reveal?: boolean;
}

// Start / pause menu. The blurred backdrop is the live 3D game scene rendered behind it.
export const MainMenu: React.FC<MainMenuProps> = ({ resumeMode, isMuted, onPlay, onHelp, onMusic, onToggleMute, reveal = true }) => {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!reveal) return;
    const id = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(id);
  }, [reveal]);

  // Fixed pseudo-random sparkle layout around the logo
  const sparkles = React.useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        left: 4 + ((i * 53) % 92),
        top: 20 + ((i * 37) % 70),
        size: 4 + ((i * 7) % 7),
        delay: ((i * 0.37) % 4).toFixed(2),
        dur: (3 + ((i * 0.23) % 2.2)).toFixed(2),
      })),
    []
  );

  const btn =
    'group w-72 flex items-center justify-center gap-3 px-6 py-3 rounded-xl border border-white/20 bg-white/10 ' +
    'hover:bg-amber-400/90 hover:text-slate-900 hover:border-amber-300 text-white font-semibold tracking-wide ' +
    'backdrop-blur-md shadow-lg transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer';

  return (
    <div
      className={`absolute inset-0 z-40 flex flex-col items-center justify-center transition-opacity duration-700 ${
        visible ? 'opacity-100' : 'opacity-0'
      }`}
      style={{
        backdropFilter: 'blur(14px) saturate(1.2)',
        WebkitBackdropFilter: 'blur(14px) saturate(1.2)',
        background: 'radial-gradient(ellipse at center, rgba(2,6,23,0.25) 0%, rgba(2,6,23,0.7) 100%)',
      }}
    >
      {/* Animated game logo */}
      <div className="relative mb-8 px-4 w-[min(80vw,520px)]" style={{ aspectRatio: "989 / 656" }}>
        {visible &&
          sparkles.map((sp, i) => (
            <span
              key={i}
              className="sparkle"
              style={{ left: `${sp.left}%`, top: `${sp.top}%`, width: sp.size, height: sp.size, animationDelay: `${sp.delay}s`, animationDuration: `${sp.dur}s` }}
            />
          ))}
        {visible && (
          <div className="logo-enter">
            <div className="logo-float">
              <div className="relative logo-glow">
                <img src="/img/logo.png" alt="Relic: The Lost World" draggable={false} className="w-full h-auto block" />
                <div className="logo-shine" />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-col items-center gap-4">
        <button className={btn + (visible ? ' menu-btn-in' : ' opacity-0')} style={{ animationDelay: '0.90s' }} onClick={onPlay} autoFocus>
          <Play size={20} /> {resumeMode ? 'Resume' : 'Start Adventure'}
        </button>
        <button className={btn + (visible ? ' menu-btn-in' : ' opacity-0')} style={{ animationDelay: '1.02s' }} onClick={onHelp}>
          <BookOpen size={20} /> How to Play
        </button>
        <button className={btn + (visible ? ' menu-btn-in' : ' opacity-0')} style={{ animationDelay: '1.14s' }} onClick={onMusic}>
          <Music size={20} /> Music
        </button>
        <button className={btn + (visible ? ' menu-btn-in' : ' opacity-0')} style={{ animationDelay: '1.26s' }} onClick={onToggleMute}>
          {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />} Sound: {isMuted ? 'Off' : 'On'}
        </button>
      </div>

      <p className="absolute bottom-6 text-slate-300/70 text-xs">Press Esc during the game to return to this menu</p>
    </div>
  );
};
