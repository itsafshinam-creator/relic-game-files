import React, { useEffect, useRef, useState } from 'react';

interface SplashScreenProps {
  /** Called when the fade-out begins (menu can start revealing underneath). */
  onFadeStart: () => void;
  /** Called when the splash is fully gone. */
  onDone: () => void;
}

const HOLD_MS = 5200; // total time the image is shown before fading
const FADE_MS = 1400;

// Canvas of wind-blown dust motes, soft leaves/embers and faint wind streaks.
const WindDust: React.FC = () => {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let w = 0, h = 0, raf = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    type P = { x: number; y: number; r: number; vx: number; ph: number; fr: number; a: number; warm: number; kind: number };
    const rnd = (a: number, b: number) => a + Math.random() * (b - a);
    const make = (initial: boolean): P => ({
      x: initial ? rnd(0, w) : rnd(-80, -5),
      y: rnd(h * 0.25, h * 1.0),
      r: rnd(0.6, 2.6),
      vx: rnd(35, 110),
      ph: rnd(0, Math.PI * 2),
      fr: rnd(0.6, 1.8),
      a: rnd(0.18, 0.7),
      warm: Math.random(),
      kind: Math.random() < 0.12 ? 1 : 0, // 1 = longer wind streak
    });
    const parts: P[] = Array.from({ length: 150 }, () => make(true));

    let last = performance.now();
    let t = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
      ctx.clearRect(0, 0, w, h);
      // gusts: slow global wind strength oscillation
      const gust = 0.75 + 0.5 * Math.sin(t * 0.7) * Math.sin(t * 0.31 + 1.2);
      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        p.x += p.vx * gust * dt * (p.kind ? 2.4 : 1);
        p.y += Math.sin(t * p.fr + p.ph) * 18 * dt - 4 * dt;
        if (p.x > w + 40 || p.y < -20) { parts[i] = make(false); continue; }
        const col = p.warm > 0.5 ? '255,226,170' : '210,225,235';
        if (p.kind) {
          const len = 40 + p.vx * gust * 0.5;
          const g = ctx.createLinearGradient(p.x - len, p.y, p.x, p.y);
          g.addColorStop(0, 'rgba(' + col + ',0)');
          g.addColorStop(1, 'rgba(' + col + ',' + (p.a * 0.35).toFixed(3) + ')');
          ctx.strokeStyle = g; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(p.x - len, p.y); ctx.lineTo(p.x, p.y); ctx.stroke();
        } else {
          ctx.fillStyle = 'rgba(' + col + ',' + p.a.toFixed(3) + ')';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={ref} className="absolute inset-0 w-full h-full pointer-events-none" />;
};

// Launch screen: key art fades in from black with a slow cinematic push-in, then dissolves into the menu.
export const SplashScreen: React.FC<SplashScreenProps> = ({ onFadeStart, onDone }) => {
  const [phase, setPhase] = useState<'in' | 'out'>('in');
  const finished = useRef(false);

  const startFade = () => {
    if (finished.current) return;
    finished.current = true;
    setPhase('out');
    onFadeStart();
    window.setTimeout(onDone, FADE_MS);
  };

  useEffect(() => {
    const t = window.setTimeout(startFade, HOLD_MS);
    const skip = () => startFade();
    window.addEventListener('keydown', skip);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener('keydown', skip);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      className="absolute inset-0 z-[60] bg-black overflow-hidden cursor-pointer"
      style={{ opacity: phase === 'out' ? 0 : 1, transition: `opacity ${FADE_MS}ms ease-in-out`, pointerEvents: phase === 'out' ? 'none' : 'auto' }}
      onPointerDown={startFade}
    >
      <img
        src="/img/launch.jpg"
        alt="Relic: The Lost World"
        draggable={false}
        className="splash-art absolute inset-0 w-full h-full object-cover"
      />
      {/* vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,0.65) 100%)' }}
      />
      {/* drifting ground fog / dust haze */}
      <div className="splash-haze splash-haze-a absolute pointer-events-none" />
      <div className="splash-haze splash-haze-b absolute pointer-events-none" />
      {/* wind-blown dust particles */}
      <WindDust />
      {/* light sweep across the art */}
      <div className="splash-sweep absolute inset-0 pointer-events-none" />
    </div>
  );
};
