import * as THREE from 'three';
import { createMaterials } from './materials';

export function buildRelicFoliage(scene: THREE.Scene, colliders: THREE.Box3[]) {
  const mats = createMaterials();

  const matOakLeaf = new THREE.MeshStandardMaterial({ color: '#3A7D44', roughness: 0.65 });
  const matDeadWood = new THREE.MeshStandardMaterial({ color: '#574136', roughness: 0.85 });
  const matPalmLeaf = new THREE.MeshStandardMaterial({ color: '#16A34A', roughness: 0.55 });
  const matMoss = new THREE.MeshStandardMaterial({ color: '#4D7C0F', roughness: 0.8 });
  const matFern = new THREE.MeshStandardMaterial({ color: '#22C55E', roughness: 0.6 });

  // 1. Oak Trees (Broad leafy trees)
  function createOakTree(x: number, z: number, scale = 1.0) {
    const oak = new THREE.Group();
    oak.position.set(x, 0, z);

    // Thick trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.45 * scale, 0.6 * scale, 3.2 * scale, 8), mats.woodLog);
    trunk.position.y = 1.6 * scale;
    trunk.castShadow = true;
    oak.add(trunk);

    // Broad round canopy spheres
    const canopy1 = new THREE.Mesh(new THREE.DodecahedronGeometry(2.4 * scale, 1), matOakLeaf);
    canopy1.position.y = 4.0 * scale;
    canopy1.castShadow = true;
    oak.add(canopy1);

    const canopy2 = new THREE.Mesh(new THREE.DodecahedronGeometry(1.8 * scale, 1), matOakLeaf);
    canopy2.position.set(1.1 * scale, 3.8 * scale, 0.5 * scale);
    canopy2.castShadow = true;
    oak.add(canopy2);

    const canopy3 = new THREE.Mesh(new THREE.DodecahedronGeometry(1.7 * scale, 1), matOakLeaf);
    canopy3.position.set(-1.0 * scale, 3.6 * scale, -0.6 * scale);
    canopy3.castShadow = true;
    oak.add(canopy3);

    scene.add(oak);

    const box = new THREE.Box3();
    box.setFromCenterAndSize(new THREE.Vector3(x, 2.0 * scale, z), new THREE.Vector3(1.2 * scale, 4.0 * scale, 1.2 * scale));
    colliders.push(box);
  }

  // 2. Dead Trees (Gnarled spooky bare branches)
  function createDeadTree(x: number, z: number, scale = 1.0) {
    const dead = new THREE.Group();
    dead.position.set(x, 0, z);

    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.35 * scale, 0.45 * scale, 4.5 * scale, 7), matDeadWood);
    trunk.position.y = 2.25 * scale;
    trunk.castShadow = true;
    dead.add(trunk);

    // Bare crooked branches
    for (let i = 0; i < 4; i++) {
      const angle = (i / 4) * Math.PI * 2;
      const branch = new THREE.Mesh(new THREE.CylinderGeometry(0.08 * scale, 0.14 * scale, 2.2 * scale, 6), matDeadWood);
      branch.position.set(Math.cos(angle) * 0.7 * scale, (3.2 + (i % 2) * 0.6) * scale, Math.sin(angle) * 0.7 * scale);
      branch.rotation.z = Math.PI / 3;
      branch.rotation.y = angle;
      branch.castShadow = true;
      dead.add(branch);
    }

    scene.add(dead);

    const box = new THREE.Box3();
    box.setFromCenterAndSize(new THREE.Vector3(x, 2.0 * scale, z), new THREE.Vector3(1.0 * scale, 4.0 * scale, 1.0 * scale));
    colliders.push(box);
  }

  // 3. Palm Trees (Near the river pond)
  function createPalmTree(x: number, z: number) {
    const palm = new THREE.Group();
    palm.position.set(x, 0, z);

    // Curved slender segmented trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.32, 6.2, 8), mats.woodLog);
    trunk.position.set(0.4, 3.1, 0);
    trunk.rotation.z = -0.12;
    trunk.castShadow = true;
    palm.add(trunk);

    // Radiating Palm Fronds
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const frond = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.05, 2.6), matPalmLeaf);
      frond.position.set(Math.cos(angle) * 1.3, 6.1, Math.sin(angle) * 1.3);
      frond.rotation.y = angle;
      frond.rotation.x = 0.4;
      frond.castShadow = true;
      palm.add(frond);
    }

    scene.add(palm);

    const box = new THREE.Box3();
    box.setFromCenterAndSize(new THREE.Vector3(x, 3.0, z), new THREE.Vector3(0.8, 6.0, 0.8));
    colliders.push(box);
  }

  // 4. Mossy Boulders & Ferns
  function createMossyRock(x: number, z: number, size = 1.0) {
    const rock = new THREE.Group();
    rock.position.set(x, 0, z);

    const rockMesh = new THREE.Mesh(new THREE.DodecahedronGeometry(size), mats.ruinStone);
    rockMesh.position.y = size * 0.7;
    rockMesh.scale.set(1.2, 0.9, 1.1);
    rockMesh.castShadow = true;
    rock.add(rockMesh);

    // Moss cap
    const mossCap = new THREE.Mesh(new THREE.SphereGeometry(size * 0.95, 8, 8, 0, Math.PI * 2, 0, Math.PI / 2), matMoss);
    mossCap.position.y = size * 0.75;
    mossCap.scale.set(1.2, 0.9, 1.1);
    rock.add(mossCap);

    scene.add(rock);

    const box = new THREE.Box3();
    box.setFromCenterAndSize(new THREE.Vector3(x, size * 0.7, z), new THREE.Vector3(size * 2, size * 1.4, size * 2));
    colliders.push(box);
  }

  // The Base camp's trees, grass and flowers are the Lego-brick set in legoNature.ts.
  // Here we keep only the rocks, plus gnarled dead trees for the gloomy Stage 1 beyond the gate.
  createMossyRock(-14, 16, 0.9);
  createMossyRock(12, -8, 1.1);
  createMossyRock(-6, -26, 1.3);

  // Stage 1 (north of the gate): spooky dead trees along the fighting corridor
  createDeadTree(-33, -54, 1.1);
  createDeadTree(-15, -58, 1.0);
  createDeadTree(-31, -70, 1.15);
  createDeadTree(-16, -80, 1.0);
  createDeadTree(-30, -84, 0.95);
}
