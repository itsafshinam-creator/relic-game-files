import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

/**
 * Lego-brick nature for the Base camp (and a gloomier version for Stage 1).
 *
 * Modelled on the reference photos: brown stepped trunks with flared "root" wedges,
 * canopies made of stacked 6-arm leaf plates with studs, apple trees with red/green apples,
 * a tall leafy cypress bush and a curved bonsai-style tree, standing on round green stud plates.
 *
 * Everything is merged into one vertex-coloured geometry per species and drawn with
 * InstancedMesh, so hundreds of trees and thousands of grass tufts cost only a handful of draw calls.
 */

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface Xform {
  x?: number;
  y?: number;
  z?: number;
  rx?: number;
  ry?: number;
  rz?: number;
  sx?: number;
  sy?: number;
  sz?: number;
  /** When set, overrides rx/ry/rz. */
  q?: THREE.Quaternion;
}

/** Collects coloured primitives and merges them into a single BufferGeometry. */
class PartBuilder {
  private parts: THREE.BufferGeometry[] = [];
  private readonly tmpColor = new THREE.Color();

  add(geo: THREE.BufferGeometry, color: string, t: Xform = {}): this {
    const g = geo.clone();
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(t.x ?? 0, t.y ?? 0, t.z ?? 0),
      t.q ?? new THREE.Quaternion().setFromEuler(new THREE.Euler(t.rx ?? 0, t.ry ?? 0, t.rz ?? 0, 'YXZ')),
      new THREE.Vector3(t.sx ?? 1, t.sy ?? 1, t.sz ?? 1)
    );
    g.applyMatrix4(m);
    this.tmpColor.set(color);
    const n = g.attributes.position.count;
    const col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      col[i * 3] = this.tmpColor.r;
      col[i * 3 + 1] = this.tmpColor.g;
      col[i * 3 + 2] = this.tmpColor.b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    this.parts.push(g);
    geo.dispose();
    return this;
  }

  build(): THREE.BufferGeometry {
    const merged = mergeGeometries(this.parts, false)!;
    this.parts.forEach((p) => p.dispose());
    this.parts = [];
    merged.computeBoundingSphere();
    merged.computeBoundingBox();
    return merged;
  }
}

/** Child placed in a rotated frame: yaw around Y, then local offset, then local tilt. */
function framed(yaw: number, ox: number, oy: number, oz: number, tilt: Xform = {}): Xform {
  // Position the part at (ox, oy, oz) rotated by `yaw` around the Y axis.
  const c = Math.cos(yaw);
  const s = Math.sin(yaw);
  return {
    x: ox * c + oz * s,
    y: oy,
    z: -ox * s + oz * c,
    ry: yaw + (tilt.ry ?? 0),
    rx: tilt.rx ?? 0,
    rz: tilt.rz ?? 0,
    sx: tilt.sx,
    sy: tilt.sy,
    sz: tilt.sz,
  };
}

// ---------------------------------------------------------------------------
// Palette (taken from the reference photos)
// ---------------------------------------------------------------------------

const C = {
  trunkA: '#6B3F26',
  trunkB: '#7B4A2E',
  trunkC: '#5A3320',
  leafDark: '#1E5C2B',
  leafMid: '#2E9B3E',
  leafLight: '#52BE4A',
  leafLime: '#7CD65A',
  appleRed: '#CF1B17',
  appleGreen: '#4FA83A',
  stemGreen: '#2C7A2F',
  plate: '#58A84A',
  plateStud: '#6BBE58',
  grassA: '#3E9B34',
  grassB: '#5DB84A',
  grassC: '#82CF5B',
  grassBase: '#2F7D2E',
};

// ---------------------------------------------------------------------------
// Reusable brick parts
// ---------------------------------------------------------------------------

/** A flat 6-arm leaf plate with forked arms and a stud on every tip (like the LEGO "leaves" piece). */
function addLeafPlate(
  b: PartBuilder,
  cx: number,
  cy: number,
  cz: number,
  yaw: number,
  scale: number,
  colors: [string, string],
  tilt: { rx?: number; rz?: number } = {}
) {
  const [main, tip] = colors;
  const s = scale;
  const armLen = 1.15 * s;
  const armW = 0.17 * s;
  const armH = 0.09 * s;

  // Whole-plate frame: yaw, then a small tilt. Every part is placed and oriented inside it.
  const frame = new THREE.Quaternion()
    .setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw)
    .multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(tilt.rx ?? 0, 0, tilt.rz ?? 0, 'XYZ')));
  const place = (lx: number, ly: number, lz: number, localYaw: number): Xform => {
    const v = new THREE.Vector3(lx, ly, lz).applyQuaternion(frame);
    const q = frame.clone().multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), localYaw));
    return { x: cx + v.x, y: cy + v.y, z: cz + v.z, q };
  };

  b.add(new THREE.CylinderGeometry(0.3 * s, 0.34 * s, armH, 8), main, place(0, 0, 0, 0));
  b.add(new THREE.CylinderGeometry(0.12 * s, 0.12 * s, 0.07 * s, 8), tip, place(0, armH * 0.9, 0, 0));

  const tipStud = new THREE.CylinderGeometry(0.095 * s, 0.095 * s, 0.1 * s, 6);
  const armGeo = new THREE.BoxGeometry(1, armH, armW);

  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * Math.PI * 2;
    const ax = Math.cos(a);
    const az = -Math.sin(a);

    // Main arm along local +X rotated by `a`, with a stud on its tip
    b.add(armGeo, main, { ...place(ax * armLen * 0.5, 0, az * armLen * 0.5, a), sx: armLen });
    b.add(tipStud, tip, place(ax * armLen, armH * 0.6, az * armLen, 0));

    // Two forks branching off at ~38 degrees
    const forkLen = 0.52 * s;
    const baseAt = armLen * 0.58;
    [-1, 1].forEach((side) => {
      const fa = a + side * 0.66;
      const fx0 = ax * baseAt;
      const fz0 = az * baseAt;
      const fdx = Math.cos(fa);
      const fdz = -Math.sin(fa);
      b.add(armGeo, main, { ...place(fx0 + fdx * forkLen * 0.5, 0, fz0 + fdz * forkLen * 0.5, fa), sx: forkLen, sz: 0.85 });
      b.add(tipStud, tip, place(fx0 + fdx * forkLen, armH * 0.6, fz0 + fdz * forkLen, 0));
    });
  }
  armGeo.dispose();
  tipStud.dispose();
}

/** Stepped brick trunk with four flared root wedges, like the big oak in the photo. */
function addBrickTrunk(b: PartBuilder, height: number, thickness: number, shades: [string, string, string] = [C.trunkA, C.trunkB, C.trunkC]) {
  const t = thickness;
  // Root wedges (slope pieces) in a cross shape
  for (let k = 0; k < 4; k++) {
    const yaw = (k * Math.PI) / 2;
    const wedge = new THREE.BoxGeometry(1.5 * t, 0.46 * t, 0.62 * t);
    b.add(wedge, k % 2 === 0 ? shades[1] : shades[0], {
      ...framed(yaw, 0.92 * t, 0.3 * t, 0),
      rz: -0.42,
    });
    // inner buttress block that blends the wedge into the trunk
    b.add(new THREE.BoxGeometry(0.7 * t, 0.9 * t, 0.46 * t), shades[2], framed(yaw, 0.55 * t, 0.45 * t, 0));
  }
  // Stacked octagonal courses (alternating brick shades, slight taper)
  const courses = Math.max(3, Math.round(height / 0.95));
  const ch = height / courses;
  for (let i = 0; i < courses; i++) {
    const f = i / courses;
    const rBot = (0.78 - f * 0.2) * t;
    const rTop = (0.78 - (f + 1 / courses) * 0.2) * t;
    b.add(new THREE.CylinderGeometry(rTop, rBot, ch * 1.01, 8), shades[i % 2], { y: 0.35 * t + ch * (i + 0.5), ry: (i % 2) * 0.39 });
  }
  // Two vertical bark ribs (the fins visible on the photo's oak)
  [0.7, -0.7].forEach((o) => {
    b.add(new THREE.BoxGeometry(0.16 * t, height * 0.72, 0.34 * t), shades[2], { x: o * t * 0.55, y: 0.35 * t + height * 0.42, z: 0.4 * t, ry: o * 0.4 });
  });
}

function addApple(b: PartBuilder, x: number, y: number, z: number, color: string, size = 1) {
  b.add(new THREE.SphereGeometry(0.15 * size, 8, 6), color, { x, y, z, sy: 0.92 });
  b.add(new THREE.CylinderGeometry(0.02 * size, 0.02 * size, 0.1 * size, 4), C.trunkC, { x, y: y + 0.16 * size, z });
  b.add(new THREE.BoxGeometry(0.1 * size, 0.02 * size, 0.06 * size), C.stemGreen, { x: x + 0.06 * size, y: y + 0.19 * size, z, rz: 0.4 });
}

// ---------------------------------------------------------------------------
// Species
// ---------------------------------------------------------------------------

/** Big brick oak (second photo): flared roots, three tiers of dark/mid/light leaf plates. */
function buildOak(): THREE.BufferGeometry {
  const b = new PartBuilder();
  addBrickTrunk(b, 3.5, 1.0);
  const tiers: Array<{ y: number; r: number; n: number; s: number; off: number }> = [
    { y: 3.75, r: 0.95, n: 3, s: 1.05, off: 0.2 },
    { y: 4.4, r: 0.75, n: 2, s: 1.1, off: 1.0 },
    { y: 5.05, r: 0.4, n: 1, s: 1.0, off: 0.5 },
  ];
  const greens: Array<[string, string]> = [
    [C.leafDark, C.leafDark],
    [C.leafMid, C.leafLight],
    [C.leafLight, C.leafLime],
  ];
  tiers.forEach((tier, ti) => {
    for (let i = 0; i < tier.n; i++) {
      const a = tier.off + (i / tier.n) * Math.PI * 2;
      const px = Math.cos(a) * tier.r;
      const pz = Math.sin(a) * tier.r;
      addLeafPlate(b, px, tier.y, pz, a * 1.7 + ti, tier.s, greens[(i + ti) % 3], { rx: (i - 1) * 0.04, rz: (ti - 1) * 0.05 });
      // little branch stub from the trunk top to the plate
      b.add(new THREE.BoxGeometry(Math.hypot(px, pz) + 0.15, 0.16, 0.18), C.trunkB, {
        x: px / 2,
        y: tier.y - 0.2,
        z: pz / 2,
        ry: -Math.atan2(pz, px),
      });
    }
  });
  addLeafPlate(b, 0, 5.5, 0, 0.3, 0.8, [C.leafLight, C.leafLime]);
  b.add(new THREE.CylinderGeometry(0.1, 0.12, 1.9, 6), C.trunkB, { y: 4.7 });
  return b.build();
}

/** Apple tree (first photo, top): bright wide canopy dotted with red and green apples. */
function buildAppleTree(): THREE.BufferGeometry {
  const b = new PartBuilder();
  addBrickTrunk(b, 2.9, 1.05);
  // a curved side branch like the photo
  b.add(new THREE.BoxGeometry(0.3, 1.3, 0.3), C.trunkB, { x: 0.45, y: 3.45, z: 0.1, rz: -0.55 });
  b.add(new THREE.BoxGeometry(0.28, 1.1, 0.28), C.trunkA, { x: 1.05, y: 4.05, z: 0.1, rz: -1.0 });
  const plates: Array<[number, number, number, number, [string, string]]> = [
    [0, 3.55, 0, 1.3, [C.leafMid, C.leafLight]],
    [1.4, 3.95, 0.5, 1.15, [C.leafLight, C.leafLime]],
    [-1.35, 3.8, -0.5, 1.2, [C.leafMid, C.leafLime]],
    [0.3, 3.95, -1.45, 1.1, [C.leafLight, C.leafLight]],
    [-0.3, 4.0, 1.4, 1.15, [C.leafMid, C.leafLight]],
    [0, 4.55, 0, 1.2, [C.leafLight, C.leafLime]],
  ];
  plates.forEach(([x, y, z, s, col], i) => addLeafPlate(b, x, y, z, i * 0.9, s, col, { rx: Math.sin(i) * 0.05, rz: Math.cos(i) * 0.05 }));
  // support rods under the plates
  [[1.4, 0.5], [-1.35, -0.5], [0.3, -1.45], [-0.3, 1.4]].forEach(([x, z]) => {
    b.add(new THREE.CylinderGeometry(0.1, 0.1, 1.0, 6), C.trunkB, { x: x * 0.7, y: 3.2, z: z * 0.7, rz: -x * 0.09, rx: z * 0.09 });
  });
  // apples hanging under and around the canopy
  const apples: Array<[number, number, number, string]> = [
    [1.7, 3.65, 0.8, C.appleRed],
    [-1.8, 3.5, -0.2, C.appleRed],
    [0.6, 3.5, -1.9, C.appleRed],
    [-0.9, 3.55, 1.9, C.appleGreen],
    [1.9, 3.7, -0.7, C.appleGreen],
    [-0.4, 3.35, 0.6, C.appleRed],
    [1.0, 3.4, 1.4, C.appleRed],
    [-1.9, 3.55, 1.0, C.appleRed],
    [0.2, 3.5, -0.9, C.appleGreen],
    [2.0, 3.85, 0.1, C.appleRed],
  ];
  apples.forEach(([x, y, z, c]) => addApple(b, x, y, z, c));
  return b.build();
}

/** Tall leafy cypress bush (first photo, left): stacked leaf plates forming an egg shape with a sprout on top. */
function buildCypress(): THREE.BufferGeometry {
  const b = new PartBuilder();
  b.add(new THREE.CylinderGeometry(0.2, 0.26, 1.0, 8), C.trunkA, { y: 0.5 });
  b.add(new THREE.CylinderGeometry(0.34, 0.4, 0.2, 8), C.trunkC, { y: 0.12 });
  const profile = [0.78, 1.0, 1.08, 1.0, 0.85, 0.6];
  const cols: Array<[string, string]> = [
    [C.leafDark, C.leafMid],
    [C.leafMid, C.leafLight],
    [C.leafLight, C.leafLime],
  ];
  profile.forEach((s, i) => {
    const y = 0.95 + i * 0.5;
    addLeafPlate(b, 0, y, 0, i * 0.6, s * 0.78, cols[i % 3]);
    // every other level also gets a tilted plate, like leaves peeking out
    if (i % 2 === 1) addLeafPlate(b, 0, y + 0.22, 0, i * 0.6 + 0.5, s * 0.6, cols[(i + 1) % 3], { rx: 0.45, rz: -0.35 });
  });
  b.add(new THREE.CylinderGeometry(0.03, 0.09, 0.7, 5), C.leafLime, { y: 4.1 });
  b.add(new THREE.BoxGeometry(0.34, 0.03, 0.12), C.leafLight, { x: 0.17, y: 3.95, rz: 0.55 });
  b.add(new THREE.BoxGeometry(0.34, 0.03, 0.12), C.leafLight, { x: -0.17, y: 3.95, rz: -0.55 });
  return b.build();
}

/** Curved bonsai/pine tree (first photo, right): bent trunk with wide flat layered canopies. */
function buildBonsai(): THREE.BufferGeometry {
  const b = new PartBuilder();
  // Curved trunk made of short tilted courses
  const segs = 7;
  let px = 0;
  let py = 0;
  for (let i = 0; i < segs; i++) {
    const f = i / segs;
    const len = 0.62;
    const lean = 0.34 - f * 0.55; // bends one way then straightens
    const r0 = 0.46 - f * 0.18;
    b.add(new THREE.CylinderGeometry(r0 - 0.03, r0, len * 1.08, 8), i % 2 ? C.trunkB : C.trunkA, {
      x: px + Math.sin(lean) * len * 0.5,
      y: py + Math.cos(lean) * len * 0.5,
      rz: -lean,
    });
    px += Math.sin(lean) * len;
    py += Math.cos(lean) * len;
  }
  const cols: Array<[string, string]> = [
    [C.leafMid, C.leafMid],
    [C.leafLight, C.leafLight],
    [C.leafDark, C.leafMid],
  ];
  const layers: Array<{ x: number; y: number; z: number; s: number }> = [
    { x: px + 0.7, y: py - 1.35, z: 0.2, s: 1.35 },
    { x: px - 0.3, y: py - 0.75, z: 0.9, s: 1.1 },
    { x: px + 0.5, y: py - 0.2, z: -0.2, s: 1.25 },
    { x: px, y: py + 0.7, z: 0, s: 1.0 },
  ];
  layers.forEach((l, i) => {
    addLeafPlate(b, l.x, l.y, l.z, i * 1.1, l.s, cols[i % 3], { rx: Math.sin(i * 2) * 0.06, rz: Math.cos(i * 2) * 0.08 });
  });
  // limbs from the trunk to the plates
  layers.slice(0, 3).forEach((l) => {
    const len = Math.hypot(l.x - px * 0.6, l.z);
    b.add(new THREE.BoxGeometry(len, 0.14, 0.16), C.trunkB, {
      x: (l.x + px * 0.6) / 2,
      y: l.y - 0.12,
      z: l.z / 2,
      ry: -Math.atan2(l.z, l.x - px * 0.6),
      rz: 0.1,
    });
  });
  return b.build();
}

/** Round green stud plate (the little base each tree stands on in the photos). Unit radius. */
function buildStudPlate(): THREE.BufferGeometry {
  const b = new PartBuilder();
  b.add(new THREE.CylinderGeometry(1, 1, 0.07, 28), C.plate, { y: 0.035 });
  const stud = new THREE.CylinderGeometry(0.1, 0.1, 0.07, 8);
  b.add(stud, C.plateStud, { y: 0.1 });
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    b.add(stud, C.plateStud, { x: Math.cos(a) * 0.4, y: 0.1, z: Math.sin(a) * 0.4 });
  }
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 + 0.2;
    b.add(stud, C.plateStud, { x: Math.cos(a) * 0.76, y: 0.1, z: Math.sin(a) * 0.76 });
  }
  return b.build();
}

/** A Lego-style grass tuft: a few tapered blades growing out of one stud. */
function buildGrassTuft(): THREE.BufferGeometry {
  const b = new PartBuilder();
  b.add(new THREE.CylinderGeometry(0.1, 0.12, 0.06, 6), C.grassBase, { y: 0.03 });
  const blades: Array<[number, number, number, number, string]> = [
    // angle, lean, height, width, colour
    [0.0, 0.0, 0.62, 0.075, C.grassB],
    [1.3, 0.34, 0.5, 0.07, C.grassA],
    [2.5, 0.4, 0.46, 0.07, C.grassC],
    [3.8, 0.3, 0.55, 0.07, C.grassB],
    [5.0, 0.42, 0.42, 0.065, C.grassA],
    [0.7, 0.62, 0.36, 0.06, C.grassC],
  ];
  blades.forEach(([ang, lean, h, w, col]) => {
    const g = new THREE.ConeGeometry(w, h, 4, 1);
    g.translate(0, h / 2, 0);
    g.scale(1, 1, 0.45);
    // lean outward in the direction `ang`
    b.add(g, col, {
      x: Math.cos(ang) * 0.05,
      y: 0.04,
      z: Math.sin(ang) * 0.05,
      ry: -ang,
      rz: -lean,
    });
  });
  return b.build();
}

function buildFlower(petal: string, centre: string): THREE.BufferGeometry {
  const b = new PartBuilder();
  b.add(new THREE.CylinderGeometry(0.018, 0.018, 0.3, 5), C.stemGreen, { y: 0.15 });
  b.add(new THREE.BoxGeometry(0.16, 0.02, 0.05), C.stemGreen, { x: 0.07, y: 0.1, rz: 0.5 });
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    b.add(new THREE.CylinderGeometry(0.06, 0.06, 0.025, 6), petal, { x: Math.cos(a) * 0.09, y: 0.31, z: Math.sin(a) * 0.09 });
  }
  b.add(new THREE.CylinderGeometry(0.05, 0.05, 0.05, 6), centre, { y: 0.325 });
  return b.build();
}

// ---------------------------------------------------------------------------
// Placement
// ---------------------------------------------------------------------------

type Species = 'oak' | 'apple' | 'cypress' | 'bonsai';

interface TreeSpot {
  x: number;
  z: number;
  species: Species;
  scale: number;
  yaw: number;
}

interface Blocker {
  x: number;
  z: number;
  /** radius for circular blockers; ignored when hw/hd are set */
  r?: number;
  hw?: number;
  hd?: number;
}

/** Everything in the Base that trees / grass must not grow on. */
const BASE_BLOCKERS: Blocker[] = [
  // roads
  { x: 0, z: 10, hw: 8.2, hd: 27 },
  { x: 0, z: -5, hw: 33.5, hd: 5.2 },
  // pond + bridge
  { x: -18, z: 20, r: 9 },
  { x: -18, z: 12, r: 5.5 },
  // campfire camp
  { x: -6, z: 8, r: 5 },
  { x: -10, z: 10, r: 4.5 },
  // buildings
  { x: 16, z: 14, hw: 7.5, hd: 7 },
  { x: 20, z: -2, hw: 7.5, hd: 7 },
  { x: 0, z: -32, hw: 11.5, hd: 9.5 },
  { x: -20, z: -6, r: 6 },
  { x: -28, z: 18, r: 5 },
  // the gate and the path leading to it
  { x: -24, z: -34, hw: 7.5, hd: 9 },
  // props / NPCs / loot (approximate)
  { x: 4, z: 2, r: 2.6 },
  { x: 12, z: 4, r: 3.2 },
  { x: 0, z: 7, r: 2 },
  { x: 18, z: 1, r: 2.6 },
  { x: 6, z: 12, hw: 2.5, hd: 6 },
  { x: 10, z: 6, r: 2.4 },
  { x: -14, z: -8, r: 2.4 },
  { x: -12, z: -18, r: 2.4 },
  { x: -26, z: 19, r: 2.4 },
  { x: -10, z: 12, r: 3 },
  { x: -12, z: 8, r: 3 },
  { x: -7, z: 5, r: 2.4 },
  { x: -16, z: 2, r: 2 },
  { x: -18, z: -4, r: 2 },
  { x: 14, z: 11, r: 3.2 },
  { x: 18, z: -4, r: 3 },
  { x: 22, z: -4, r: 2.4 },
  { x: 14, z: -6, r: 2.4 },
  { x: 26, z: 4, r: 2.4 },
  { x: 10, z: 18, r: 2.4 },
  { x: -16, z: 22, r: 2.4 },
  { x: 8, z: -12, r: 2.4 },
  { x: -10, z: -18, r: 2.4 },
  { x: 2, z: -26, r: 2.4 },
  { x: 4, z: 16, r: 2.4 },
  { x: -2, z: 6, r: 2.4 },
  // old foliage kept by relicFoliage (mossy rocks)
  { x: -14, z: 16, r: 2.4 },
  { x: 12, z: -8, r: 2.6 },
  { x: -6, z: -26, r: 3 },
];

function blocked(x: number, z: number, margin: number, blockers: Blocker[]): boolean {
  for (const b of blockers) {
    if (b.hw !== undefined && b.hd !== undefined) {
      if (Math.abs(x - b.x) < b.hw + margin && Math.abs(z - b.z) < b.hd + margin) return true;
    } else {
      const r = (b.r ?? 2) + margin;
      const dx = x - b.x;
      const dz = z - b.z;
      if (dx * dx + dz * dz < r * r) return true;
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Public builder
// ---------------------------------------------------------------------------

export interface LegoNatureOptions {
  /** Keep the shadow cost down on weak devices (fewer trees + grass tufts). */
  quality?: 'high' | 'medium';
}

const natureMaterial = () =>
  new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.32, // glossy ABS plastic
    metalness: 0.0,
  });

export function buildLegoNature(scene: THREE.Scene, colliders: THREE.Box3[], options: LegoNatureOptions = {}) {
  const quality = options.quality ?? 'high';
  const rand = mulberry32(20260711);
  const mat = natureMaterial();
  const group = new THREE.Group();
  group.name = 'LegoNature';
  scene.add(group);

  // ---- 1. Decide where trees go -------------------------------------------------------------
  const spots: TreeSpot[] = [];
  const taken: Array<{ x: number; z: number; r: number }> = [];

  const canPlace = (x: number, z: number, r: number, blockers: Blocker[], margin = 1.2) => {
    if (blocked(x, z, margin + r * 0.4, blockers)) return false;
    for (const t of taken) {
      const dx = x - t.x;
      const dz = z - t.z;
      const min = (t.r + r) * 0.82;
      if (dx * dx + dz * dz < min * min) return false;
    }
    return true;
  };

  const pickSpecies = (edge: boolean): Species => {
    const v = rand();
    if (edge) return v < 0.4 ? 'oak' : v < 0.62 ? 'bonsai' : v < 0.82 ? 'cypress' : 'apple';
    return v < 0.3 ? 'oak' : v < 0.55 ? 'apple' : v < 0.78 ? 'cypress' : 'bonsai';
  };
  const radiusOf = (sp: Species, s: number) => (sp === 'oak' ? 2.4 : sp === 'apple' ? 2.6 : sp === 'bonsai' ? 2.3 : 1.2) * s;

  const addTree = (x: number, z: number, edge: boolean, blockers: Blocker[], sMin = 0.85, sMax = 1.3): boolean => {
    const sp = pickSpecies(edge);
    const scale = sMin + rand() * (sMax - sMin);
    const r = radiusOf(sp, scale);
    if (!canPlace(x, z, r, blockers)) return false;
    spots.push({ x, z, species: sp, scale, yaw: rand() * Math.PI * 2 });
    taken.push({ x, z, r });
    return true;
  };

  // Base perimeter: a thick, overlapping forest that frames the whole camp.
  const MIN_X = -46;
  const MAX_X = 46;
  const MIN_Z = -37;
  const MAX_Z = 50;
  const gateGap = (x: number, z: number) => z < -30 && x > -30.5 && x < -17.5; // keep the gate approach open
  const ringStep = quality === 'high' ? 4.4 : 5.6;
  for (let layer = 0; layer < 2; layer++) {
    const inset = layer * 6.5;
    const x0 = MIN_X + inset;
    const x1 = MAX_X - inset;
    const z0 = MIN_Z + inset * 0.0 + (layer === 0 ? 0 : 3.2);
    const z1 = MAX_Z - inset;
    for (let x = x0; x <= x1; x += ringStep) {
      [z0, z1].forEach((zz) => {
        const jx = x + (rand() - 0.5) * 1.8;
        const jz = zz + (rand() - 0.5) * 1.8;
        if (gateGap(jx, jz)) return;
        addTree(jx, jz, true, BASE_BLOCKERS, 1.0, 1.45);
      });
    }
    for (let z = z0 + ringStep; z < z1; z += ringStep) {
      [x0, x1].forEach((xx) => {
        const jx = xx + (rand() - 0.5) * 1.8;
        const jz = z + (rand() - 0.5) * 1.8;
        addTree(jx, jz, true, BASE_BLOCKERS, 1.0, 1.45);
      });
    }
  }

  // Interior: clusters and lone trees so the camp feels lived-in and lush but stays walkable.
  const interiorTarget = quality === 'high' ? 70 : 42;
  let guard = 0;
  let interior = 0;
  while (interior < interiorTarget && guard++ < 4000) {
    const x = MIN_X + 6 + rand() * (MAX_X - MIN_X - 12);
    const z = MIN_Z + 4 + rand() * (MAX_Z - MIN_Z - 8);
    if (gateGap(x, z)) continue;
    if (addTree(x, z, false, BASE_BLOCKERS, 0.8, 1.2)) interior++;
  }

  // ---- 2. Stage 1: a gloomier forest lining the corridor north of the gate ------------------
  const stage1Spots: TreeSpot[] = [];
  const stage1Blockers: Blocker[] = [{ x: -24, z: -62, hw: 7.5, hd: 36 }]; // keep the fighting corridor open
  const stage1Taken = taken.length;
  for (let z = -40; z > -92; z -= quality === 'high' ? 4.6 : 6) {
    [-34, -14, -41, -7, -48, 0].forEach((xx, idx) => {
      if (idx > 3 && quality !== 'high') return;
      const jx = xx + (rand() - 0.5) * 3;
      const jz = z + (rand() - 0.5) * 2;
      const sp = pickSpecies(true);
      const scale = 0.95 + rand() * 0.5;
      const r = radiusOf(sp, scale);
      if (!canPlace(jx, jz, r, stage1Blockers, 0.8)) return;
      stage1Spots.push({ x: jx, z: jz, species: sp, scale, yaw: rand() * Math.PI * 2 });
      taken.push({ x: jx, z: jz, r });
    });
  }
  void stage1Taken;

  // ---- 3. Build instanced meshes per species -------------------------------------------------
  const builders: Record<Species, () => THREE.BufferGeometry> = {
    oak: buildOak,
    apple: buildAppleTree,
    cypress: buildCypress,
    bonsai: buildBonsai,
  };
  const geoms: Record<Species, THREE.BufferGeometry> = {
    oak: builders.oak(),
    apple: builders.apple(),
    cypress: builders.cypress(),
    bonsai: builders.bonsai(),
  };

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();

  const makeInstances = (list: TreeSpot[], species: Species, gloomy: boolean) => {
    const subset = list.filter((s) => s.species === species);
    if (!subset.length) return;
    const mesh = new THREE.InstancedMesh(geoms[species], mat, subset.length);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = true;
    subset.forEach((s, i) => {
      dummy.position.set(s.x, 0.07, s.z);
      dummy.rotation.set(0, s.yaw, 0);
      dummy.scale.setScalar(s.scale);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      // small per-tree colour variation; Stage 1 is darker and bluer
      const v = 0.88 + rand() * 0.22;
      if (gloomy) tint.setRGB(v * 0.55, v * 0.68, v * 0.62);
      else tint.setRGB(v, v * (0.96 + rand() * 0.08), v * 0.96);
      mesh.setColorAt(i, tint);
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
  };
  (['oak', 'apple', 'cypress', 'bonsai'] as Species[]).forEach((sp) => {
    makeInstances(spots, sp, false);
    makeInstances(stage1Spots, sp, true);
  });

  // Round stud plates under the larger trees (like the photos)
  {
    const plateGeo = buildStudPlate();
    const under = [...spots, ...stage1Spots].filter((s) => s.species !== 'cypress' || s.scale > 1.0);
    const plates = new THREE.InstancedMesh(plateGeo, mat, under.length);
    plates.receiveShadow = true;
    under.forEach((s, i) => {
      const r = radiusOf(s.species, s.scale) * 0.62;
      dummy.position.set(s.x, 0.0, s.z);
      dummy.rotation.set(0, s.yaw, 0);
      dummy.scale.set(r, 1, r);
      dummy.updateMatrix();
      plates.setMatrixAt(i, dummy.matrix);
      const gloomy = s.z < -38;
      tint.setRGB(gloomy ? 0.6 : 1, gloomy ? 0.72 : 1, gloomy ? 0.66 : 1);
      plates.setColorAt(i, tint);
    });
    plates.instanceMatrix.needsUpdate = true;
    if (plates.instanceColor) plates.instanceColor.needsUpdate = true;
    plates.computeBoundingSphere();
    group.add(plates);
  }

  // Trunk colliders (trunk only - you can walk under leaf plates)
  [...spots, ...stage1Spots].forEach((s) => {
    const half = 0.62 * s.scale;
    const box = new THREE.Box3(new THREE.Vector3(s.x - half, 0, s.z - half), new THREE.Vector3(s.x + half, 3.4 * s.scale, s.z + half));
    colliders.push(box);
  });

  // ---- 4. Grass tufts everywhere there is open ground -------------------------------------
  const tuftGeo = buildGrassTuft();
  const tufts: Array<{ x: number; z: number; s: number; yaw: number; gloomy: boolean }> = [];
  const step = quality === 'high' ? 1.35 : 1.8;
  for (let x = MIN_X; x <= MAX_X; x += step) {
    for (let z = MIN_Z - 2; z <= MAX_Z; z += step) {
      if (rand() > 0.78) continue;
      const jx = x + (rand() - 0.5) * step * 1.1;
      const jz = z + (rand() - 0.5) * step * 1.1;
      if (blocked(jx, jz, 0.4, BASE_BLOCKERS)) continue;
      tufts.push({ x: jx, z: jz, s: 0.7 + rand() * 0.9, yaw: rand() * Math.PI * 2, gloomy: false });
    }
  }
  // Extra fringe of tufts hugging every tree trunk
  spots.forEach((t) => {
    const n = 7;
    for (let i = 0; i < n; i++) {
      const a = rand() * Math.PI * 2;
      const d = 0.9 * t.scale + rand() * 1.3 * t.scale;
      const gx = t.x + Math.cos(a) * d;
      const gz = t.z + Math.sin(a) * d;
      if (blocked(gx, gz, 0.3, BASE_BLOCKERS)) continue;
      tufts.push({ x: gx, z: gz, s: 0.8 + rand() * 0.8, yaw: rand() * Math.PI * 2, gloomy: false });
    }
  });
  // Sparse, darker tufts in Stage 1
  for (let x = -44; x <= 0; x += 2.6) {
    for (let z = -38; z >= -90; z -= 2.6) {
      if (rand() > 0.5) continue;
      const jx = x + (rand() - 0.5) * 2;
      const jz = z + (rand() - 0.5) * 2;
      tufts.push({ x: jx, z: jz, s: 0.6 + rand() * 0.7, yaw: rand() * Math.PI * 2, gloomy: true });
    }
  }

  const tuftMesh = new THREE.InstancedMesh(tuftGeo, mat, tufts.length);
  tuftMesh.receiveShadow = true;
  tuftMesh.castShadow = false; // thousands of blades would only add shadow cost
  tufts.forEach((t, i) => {
    dummy.position.set(t.x, 0.0, t.z);
    dummy.rotation.set(0, t.yaw, 0);
    dummy.scale.set(t.s, t.s * (0.85 + rand() * 0.5), t.s);
    dummy.updateMatrix();
    tuftMesh.setMatrixAt(i, dummy.matrix);
    const v = 0.85 + rand() * 0.3;
    if (t.gloomy) tint.setRGB(v * 0.55, v * 0.62, v * 0.5);
    else tint.setRGB(v, v, v * 0.9);
    tuftMesh.setColorAt(i, tint);
  });
  tuftMesh.instanceMatrix.needsUpdate = true;
  if (tuftMesh.instanceColor) tuftMesh.instanceColor.needsUpdate = true;
  tuftMesh.computeBoundingSphere();
  group.add(tuftMesh);

  // ---- 5. Lego flowers -------------------------------------------------------------------------
  const flowerDefs: Array<[string, string]> = [
    ['#E5322D', '#FACC15'],
    ['#FACC15', '#F97316'],
    ['#F8FAFC', '#FACC15'],
    ['#F472B6', '#FDE047'],
    ['#38A1F3', '#FDE047'],
  ];
  const perColour = quality === 'high' ? 90 : 50;
  flowerDefs.forEach(([petal, centre]) => {
    const geo = buildFlower(petal, centre);
    const spotsF: Array<[number, number]> = [];
    let tries = 0;
    while (spotsF.length < perColour && tries++ < 2000) {
      const x = MIN_X + 3 + rand() * (MAX_X - MIN_X - 6);
      const z = MIN_Z + 1 + rand() * (MAX_Z - MIN_Z - 2);
      if (blocked(x, z, 0.6, BASE_BLOCKERS)) continue;
      // keep clear of trunks
      if (taken.some((t) => (x - t.x) ** 2 + (z - t.z) ** 2 < 1.2)) continue;
      spotsF.push([x, z]);
    }
    const mesh = new THREE.InstancedMesh(geo, mat, spotsF.length);
    mesh.receiveShadow = true;
    spotsF.forEach(([x, z], i) => {
      dummy.position.set(x, 0, z);
      dummy.rotation.set(0, rand() * Math.PI * 2, 0);
      dummy.scale.setScalar(0.85 + rand() * 0.6);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    group.add(mesh);
  });

  return {
    group,
    treeCount: spots.length + stage1Spots.length,
    tuftCount: tufts.length,
  };
}
