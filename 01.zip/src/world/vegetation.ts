import * as THREE from 'three';
import { buildLegoNature } from './legoNature';

/**
 * Base-camp vegetation: dense Lego-brick forest, grass tufts, flowers and round stud plates.
 * (See legoNature.ts for the models, modelled on the reference photos.)
 */
export function createVegetation(scene: THREE.Scene, colliders: THREE.Box3[]) {
  // Phones / tablets get a lighter (but still full-looking) version to keep the frame rate smooth.
  const isTouch = typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0 && window.innerWidth < 1100;
  return buildLegoNature(scene, colliders, { quality: isTouch ? 'medium' : 'high' });
}
