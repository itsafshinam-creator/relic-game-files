import * as THREE from 'three';

/**
 * Shared "Lego Ranger" style figure kit.
 * Every NPC and enemy is built from the same blocky minifigure parts, glossy materials,
 * studs and canvas face textures as the hero, so the whole cast matches visually.
 */

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
export function std(color: string, roughness = 0.45, metalness = 0.08): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}

export function addBox(
  parent: THREE.Object3D,
  w: number,
  h: number,
  d: number,
  mat: THREE.Material | THREE.Material[],
  x = 0,
  y = 0,
  z = 0
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

export function addStud(parent: THREE.Object3D, mat: THREE.Material, x: number, y: number, z: number, r = 0.035, h = 0.02) {
  const s = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 12), mat);
  s.position.set(x, y, z);
  s.castShadow = true;
  parent.add(s);
  return s;
}

export function addSphere(
  parent: THREE.Object3D,
  r: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  sx = 1,
  sy = 1,
  sz = 1
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), mat);
  m.position.set(x, y, z);
  m.scale.set(sx, sy, sz);
  m.castShadow = true;
  parent.add(m);
  return m;
}

export function addCyl(
  parent: THREE.Object3D,
  rTop: number,
  rBot: number,
  h: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  segs = 12
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, h, segs), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

export function enableShadows(root: THREE.Object3D) {
  root.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true;
      o.receiveShadow = true;
    }
  });
}

// ---------------------------------------------------------------------------
// Face textures (same 512px layout as the hero: eyes at y~238, mouth ~y 390)
// ---------------------------------------------------------------------------
export type FaceKind = 'human' | 'skull' | 'orc' | 'bandit' | 'golem' | 'wolf';

export interface FaceOpts {
  skin?: string;
  beard?: 'none' | 'stubble' | 'moustache' | 'full' | 'bushy';
  beardColor?: string;
  browColor?: string;
  iris?: string;
  soft?: boolean; // thinner brows + lips (Mara)
  scar?: boolean;
  maskColor?: string; // bandit mask
}

export function makeFaceTexture(kind: FaceKind, o: FaceOpts = {}): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  let seed = 7 + kind.length * 31;
  const rnd = () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };

  const eye = (cx: number, cy: number, flip: boolean, iris: string, browCol: string, soft: boolean) => {
    const dir = flip ? -1 : 1;
    ctx.save();
    ctx.fillStyle = browCol;
    ctx.beginPath();
    if (soft) {
      ctx.moveTo(cx - 54 * dir, cy - 46);
      ctx.quadraticCurveTo(cx, cy - 66, cx + 52 * dir, cy - 40);
      ctx.lineTo(cx + 50 * dir, cy - 30);
      ctx.quadraticCurveTo(cx, cy - 54, cx - 52 * dir, cy - 36);
    } else {
      ctx.moveTo(cx - 58 * dir, cy - 52);
      ctx.lineTo(cx + 54 * dir, cy - 40);
      ctx.lineTo(cx + 52 * dir, cy - 18);
      ctx.lineTo(cx - 56 * dir, cy - 30);
    }
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#F4EEE6';
    ctx.beginPath();
    ctx.moveTo(cx - 44, cy + 2);
    ctx.quadraticCurveTo(cx, cy - 34, cx + 44, cy + 2);
    ctx.quadraticCurveTo(cx, cy + 28, cx - 44, cy + 2);
    ctx.closePath();
    ctx.fill();
    ctx.save();
    ctx.clip();
    ctx.fillStyle = iris;
    ctx.beginPath();
    ctx.arc(cx, cy, 25, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#0E0805';
    ctx.beginPath();
    ctx.arc(cx, cy, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(cx - 8, cy - 8, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(20,10,5,0.3)';
    ctx.fillRect(cx - 50, cy - 40, 100, 26);
    ctx.restore();
    ctx.strokeStyle = '#140C08';
    ctx.lineWidth = soft ? 5 : 6;
    ctx.beginPath();
    ctx.moveTo(cx - 46, cy + 3);
    ctx.quadraticCurveTo(cx, cy - 36, cx + 46, cy + 3);
    ctx.stroke();
    ctx.restore();
  };

  const nose = () => {
    ctx.strokeStyle = 'rgba(0,0,0,0.25)';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(262, 262);
    ctx.lineTo(268, 308);
    ctx.lineTo(246, 314);
    ctx.stroke();
  };

  if (kind === 'human' || kind === 'bandit') {
    const skin = o.skin ?? '#E2A87F';
    ctx.fillStyle = skin;
    ctx.fillRect(0, 0, 512, 512);
    const g = ctx.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, 'rgba(255,230,200,0.15)');
    g.addColorStop(1, 'rgba(120,70,40,0.22)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 512);
    nose();

    const bc = o.beardColor ?? '#2A1B13';
    const style = o.beard ?? 'none';
    if (style === 'full' || style === 'bushy') {
      ctx.fillStyle = bc;
      ctx.beginPath();
      const top = style === 'bushy' ? 280 : 300;
      ctx.moveTo(0, top);
      ctx.quadraticCurveTo(60, top + 30, 110, 350);
      ctx.quadraticCurveTo(150, 372, 200, 372);
      ctx.lineTo(312, 372);
      ctx.quadraticCurveTo(362, 372, 402, 350);
      ctx.quadraticCurveTo(452, top + 30, 512, top);
      ctx.lineTo(512, 512);
      ctx.lineTo(0, 512);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 3;
      for (let i = 0; i < 380; i++) {
        const x = rnd() * 512;
        const y = top + rnd() * (512 - top);
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + (rnd() - 0.5) * 8, y + 6 + rnd() * 8);
        ctx.stroke();
      }
    } else if (style === 'stubble') {
      ctx.fillStyle = 'rgba(40,28,20,0.45)';
      for (let i = 0; i < 700; i++) {
        const x = 30 + rnd() * 452;
        const y = 320 + rnd() * 190;
        ctx.fillRect(x, y, 3, 3);
      }
    }
    if (style !== 'none' && style !== 'stubble') {
      ctx.fillStyle = bc;
      ctx.beginPath();
      ctx.moveTo(150, 345);
      ctx.quadraticCurveTo(256, 312, 362, 345);
      ctx.quadraticCurveTo(318, 388, 256, 368);
      ctx.quadraticCurveTo(194, 388, 150, 345);
      ctx.fill();
    }
    // Mouth
    ctx.strokeStyle = o.soft ? '#B5545A' : '#7A4638';
    ctx.lineWidth = o.soft ? 9 : 7;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(222, 392);
    ctx.quadraticCurveTo(256, o.soft ? 402 : 398, 290, 392);
    ctx.stroke();

    const brow = o.browColor ?? '#1A110C';
    const iris = o.iris ?? '#4A2B17';
    eye(160, 238, false, iris, brow, !!o.soft);
    eye(352, 238, true, iris, brow, !!o.soft);

    if (o.scar) {
      ctx.strokeStyle = '#B5655A';
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(110, 170);
      ctx.lineTo(200, 300);
      ctx.stroke();
    }

    if (kind === 'bandit') {
      // Dark-red bandana covering the lower face
      const mc = o.maskColor ?? '#7F1D1D';
      ctx.fillStyle = mc;
      ctx.beginPath();
      ctx.moveTo(0, 290);
      ctx.lineTo(512, 290);
      ctx.lineTo(512, 512);
      ctx.lineTo(0, 512);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.3)';
      ctx.lineWidth = 5;
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        ctx.moveTo(40 + i * 85, 300);
        ctx.quadraticCurveTo(70 + i * 85, 400, 40 + i * 85, 505);
        ctx.stroke();
      }
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.fillRect(0, 290, 512, 12);
    }
  } else if (kind === 'skull') {
    ctx.fillStyle = '#E6DFC9';
    ctx.fillRect(0, 0, 512, 512);
    ctx.fillStyle = 'rgba(120,100,70,0.25)';
    for (let i = 0; i < 40; i++) ctx.fillRect(rnd() * 512, rnd() * 512, 16, 4);
    // Eye sockets with faint red glow
    [160, 352].forEach((cx) => {
      ctx.fillStyle = '#0B0B0D';
      ctx.beginPath();
      ctx.ellipse(cx, 232, 52, 58, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(cx, 238, 12, 0, Math.PI * 2);
      ctx.fill();
    });
    // Nose cavity
    ctx.fillStyle = '#0B0B0D';
    ctx.beginPath();
    ctx.moveTo(256, 290);
    ctx.lineTo(228, 350);
    ctx.lineTo(284, 350);
    ctx.closePath();
    ctx.fill();
    // Teeth
    ctx.fillStyle = '#F5F1E4';
    ctx.fillRect(130, 400, 252, 78);
    ctx.strokeStyle = '#2B2B2B';
    ctx.lineWidth = 6;
    for (let i = 0; i <= 7; i++) {
      ctx.beginPath();
      ctx.moveTo(130 + i * 36, 400);
      ctx.lineTo(130 + i * 36, 478);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(130, 439);
    ctx.lineTo(382, 439);
    ctx.stroke();
    // crack
    ctx.beginPath();
    ctx.moveTo(300, 20);
    ctx.lineTo(280, 90);
    ctx.lineTo(310, 140);
    ctx.stroke();
  } else if (kind === 'orc') {
    ctx.fillStyle = o.skin ?? '#4F7A3F';
    ctx.fillRect(0, 0, 512, 512);
    const g = ctx.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, 'rgba(180,230,140,0.12)');
    g.addColorStop(1, 'rgba(10,30,10,0.3)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 512);
    nose();
    // heavy angry brows
    ctx.fillStyle = '#16210F';
    [false, true].forEach((flip) => {
      const cx = flip ? 352 : 160;
      const d = flip ? -1 : 1;
      ctx.beginPath();
      ctx.moveTo(cx - 62 * d, 200);
      ctx.lineTo(cx + 56 * d, 236);
      ctx.lineTo(cx + 56 * d, 262);
      ctx.lineTo(cx - 62 * d, 226);
      ctx.closePath();
      ctx.fill();
    });
    // yellow eyes with red pupils
    [160, 352].forEach((cx) => {
      ctx.fillStyle = '#FACC15';
      ctx.beginPath();
      ctx.ellipse(cx, 262, 36, 24, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#7F1D1D';
      ctx.beginPath();
      ctx.arc(cx, 264, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0D1409';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.ellipse(cx, 262, 36, 24, 0, 0, Math.PI * 2);
      ctx.stroke();
    });
    // mouth + tusks
    ctx.fillStyle = '#1B0F0F';
    ctx.fillRect(150, 380, 212, 54);
    ctx.fillStyle = '#F5F1E4';
    [[165, 380], [330, 380]].forEach(([tx, ty]) => {
      ctx.beginPath();
      ctx.moveTo(tx, ty + 6);
      ctx.lineTo(tx + 26, ty + 6);
      ctx.lineTo(tx + 13, ty - 70);
      ctx.closePath();
      ctx.fill();
    });
    if (o.scar !== false) {
      ctx.strokeStyle = '#A33D3D';
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(380, 120);
      ctx.lineTo(430, 320);
      ctx.stroke();
    }
  } else if (kind === 'golem') {
    ctx.fillStyle = '#475569';
    ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = 'rgba(15,23,42,0.5)';
    ctx.lineWidth = 6;
    for (let i = 0; i < 9; i++) {
      ctx.beginPath();
      ctx.moveTo(rnd() * 512, rnd() * 512);
      ctx.lineTo(rnd() * 512, rnd() * 512);
      ctx.stroke();
    }
    [150, 362].forEach((cx) => {
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(cx - 62, 190, 124, 80);
      ctx.fillStyle = '#38BDF8';
      ctx.fillRect(cx - 46, 214, 92, 32);
      ctx.fillStyle = '#E0F2FE';
      ctx.fillRect(cx - 30, 222, 60, 12);
    });
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(130, 360, 252, 40);
    ctx.fillStyle = '#38BDF8';
    ctx.fillRect(150, 370, 212, 14);
  } else {
    // wolf
    ctx.fillStyle = o.skin ?? '#566274';
    ctx.fillRect(0, 0, 512, 512);
    ctx.fillStyle = '#8B97A8';
    ctx.fillRect(0, 330, 512, 182);
    ctx.fillStyle = 'rgba(20,24,32,0.5)';
    for (let i = 0; i < 40; i++) ctx.fillRect(rnd() * 512, rnd() * 330, 5, 22);
    [150, 362].forEach((cx) => {
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.moveTo(cx - 52, 230);
      ctx.lineTo(cx + 52, 200);
      ctx.lineTo(cx + 40, 252);
      ctx.lineTo(cx - 44, 262);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#1B0A0A';
      ctx.fillRect(cx - 8, 218, 16, 30);
    });
    ctx.fillStyle = '#0B0B0D';
    ctx.beginPath();
    ctx.ellipse(256, 372, 52, 36, 0, 0, Math.PI * 2);
    ctx.fill();
    // fangs
    ctx.fillStyle = '#F5F1E4';
    [150, 350].forEach((tx) => {
      ctx.beginPath();
      ctx.moveTo(tx, 430);
      ctx.lineTo(tx + 34, 430);
      ctx.lineTo(tx + 17, 488);
      ctx.closePath();
      ctx.fill();
    });
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** Torso texture with painted ribs (skeletons). */
export function makeRibsTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#1B1B1F';
  ctx.fillRect(0, 0, 256, 256);
  ctx.strokeStyle = '#E6DFC9';
  ctx.lineWidth = 14;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(128, 8);
  ctx.lineTo(128, 248);
  ctx.stroke();
  for (let i = 0; i < 5; i++) {
    const y = 50 + i * 40;
    ctx.beginPath();
    ctx.moveTo(128, y);
    ctx.quadraticCurveTo(30, y - 16, 22, y + 22);
    ctx.moveTo(128, y);
    ctx.quadraticCurveTo(226, y - 16, 234, y + 22);
    ctx.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

// ---------------------------------------------------------------------------
// Humanoid minifigure builder (same proportions as the Lego Ranger)
// ---------------------------------------------------------------------------
export interface FigureOpts {
  scale?: number;
  skin: string;
  torso: THREE.Material | THREE.Material[];
  pants: string;
  boots: string;
  sleeve?: string | null; // null => bare (skin) arms
  bracer?: string;
  glove?: string;
  face: THREE.Texture;
  headSkin?: string; // override head colour (skull / orc)
  /** thickness multipliers */
  armW?: number;
  legW?: number;
  torsoW?: number;
}

export interface FigureRig {
  root: THREE.Group;
  body: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  foreL: THREE.Group;
  foreR: THREE.Group;
  handL: THREE.Group;
  handR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  mats: { skin: THREE.MeshStandardMaterial; pants: THREE.MeshStandardMaterial; boots: THREE.MeshStandardMaterial };
}

export function makeFigure(o: FigureOpts): FigureRig {
  const root = new THREE.Group();
  const body = new THREE.Group();
  body.position.y = 1.05;
  root.add(body);

  const aw = o.armW ?? 1;
  const lw = o.legW ?? 1;
  const tw = o.torsoW ?? 1;

  const skin = std(o.skin, 0.38, 0.05);
  const headMat = o.headSkin ? std(o.headSkin, 0.4, 0.05) : skin;
  const pants = std(o.pants, 0.55, 0.05);
  const boots = std(o.boots, 0.5, 0.12);
  const bootDark = std('#2B1A10', 0.45, 0.2);
  const sleeveMat = o.sleeve ? std(o.sleeve, 0.6, 0.05) : skin;
  const bracerMat = std(o.bracer ?? '#4A2E1D', 0.5, 0.15);
  const gloveMat = std(o.glove ?? '#341E12', 0.45, 0.2);
  const faceMat = new THREE.MeshStandardMaterial({ map: o.face, roughness: 0.38, metalness: 0.05 });

  // Torso
  const torso = new THREE.Group();
  body.add(torso);
  addBox(torso, 0.54 * tw, 0.58, 0.32, o.torso);

  // Head
  const head = new THREE.Group();
  head.position.set(0, 0.44, 0);
  body.add(head);
  addBox(head, 0.38, 0.38, 0.36, [headMat, headMat, headMat, headMat, faceMat, headMat]);
  [-0.2, 0.2].forEach((x) => addBox(head, 0.04, 0.09, 0.07, headMat, x, 0.02, -0.01));

  // Arms
  const makeArm = (side: 1 | -1) => {
    const arm = new THREE.Group();
    arm.position.set(side * (0.27 * tw + 0.08 * aw + 0.0 + 0.0), 0.18, 0);
    arm.position.x = side * (0.27 * tw + 0.08 * aw);
    body.add(arm);
    addBox(arm, 0.14 * aw, 0.22, 0.14 * aw, sleeveMat, 0, -0.1, 0);
    const fore = new THREE.Group();
    fore.position.set(0, -0.22, 0);
    arm.add(fore);
    addBox(fore, 0.15 * aw, 0.22, 0.15 * aw, bracerMat, 0, -0.1, 0);
    const hand = new THREE.Group();
    hand.position.set(0, -0.24, 0);
    fore.add(hand);
    addBox(hand, 0.12 * aw, 0.1, 0.12 * aw, gloveMat, 0, 0, 0);
    return { arm, fore, hand };
  };
  const L = makeArm(-1);
  const R = makeArm(1);

  // Legs
  const makeLeg = (side: 1 | -1) => {
    const leg = new THREE.Group();
    leg.position.set(side * 0.15 * lw + side * 0.0, -0.32, 0);
    leg.position.x = side * (0.15 + (lw - 1) * 0.06);
    body.add(leg);
    addBox(leg, 0.2 * lw, 0.32, 0.22 * lw, pants, 0, -0.16, 0);
    addBox(leg, 0.22 * lw, 0.34, 0.24 * lw, boots, 0, -0.48, 0);
    addBox(leg, 0.245 * lw, 0.07, 0.265 * lw, bootDark, 0, -0.34, 0);
    addBox(leg, 0.22 * lw, 0.12, 0.12, bootDark, 0, -0.59, 0.08);
    return leg;
  };

  // belt
  addBox(torso, 0.56 * tw, 0.1, 0.34, bootDark, 0, -0.25, 0);

  const rig: FigureRig = {
    root,
    body,
    head,
    torso,
    armL: L.arm,
    armR: R.arm,
    foreL: L.fore,
    foreR: R.fore,
    handL: L.hand,
    handR: R.hand,
    legL: makeLeg(-1),
    legR: makeLeg(1),
    mats: { skin, pants, boots },
  };
  if (o.scale && o.scale !== 1) root.scale.setScalar(o.scale);
  enableShadows(root);
  return rig;
}

/** Hair / hood / helmet parts that sit on the head group. */
export function addCurlyHair(head: THREE.Group, color: string, density = 1) {
  const mat = std(color, 0.4, 0.1);
  const g = new THREE.Group();
  head.add(g);
  addBox(g, 0.42, 0.13, 0.4, mat, 0, 0.17, -0.01);
  addBox(g, 0.42, 0.3, 0.12, mat, 0, 0.04, -0.2);
  [-1, 1].forEach((sx) => addBox(g, 0.06, 0.2, 0.26, mat, sx * 0.2, 0.08, -0.06));
  const geo = new THREE.SphereGeometry(1, 8, 6);
  let s = 11;
  const r = () => {
    s = (s * 16807) % 2147483647;
    return s / 2147483647;
  };
  const curl = (x: number, y: number, z: number, rad: number) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x + (r() - 0.5) * 0.02, y + (r() - 0.5) * 0.02, z + (r() - 0.5) * 0.02);
    const sc = rad * (0.9 + r() * 0.25);
    m.scale.set(sc, sc, sc);
    g.add(m);
  };
  [-0.15, -0.05, 0.05, 0.15].forEach((x) => [-0.15, -0.05, 0.05, 0.15].forEach((z) => curl(x, 0.25, z, 0.075 * density)));
  [-0.16, -0.08, 0, 0.08, 0.16].forEach((x) => curl(x, 0.17, 0.19, 0.06 * density));
  [-1, 1].forEach((sx) => [-0.14, 0, 0.1].forEach((z) => [0.15, 0.05].forEach((y) => curl(sx * 0.21, y, z, 0.065 * density))));
  [-0.16, -0.055, 0.055, 0.16].forEach((x) => [0.2, 0.1, 0].forEach((y) => curl(x, y, -0.22, 0.08 * density)));
  return g;
}

export function addShortHair(head: THREE.Group, color: string) {
  const mat = std(color, 0.45, 0.08);
  const g = new THREE.Group();
  head.add(g);
  addBox(g, 0.42, 0.12, 0.4, mat, 0, 0.19, -0.01);
  addBox(g, 0.42, 0.34, 0.1, mat, 0, 0.04, -0.2);
  [-1, 1].forEach((sx) => addBox(g, 0.05, 0.2, 0.3, mat, sx * 0.2, 0.08, -0.03));
  addBox(g, 0.4, 0.06, 0.06, mat, 0, 0.15, 0.19);
  return g;
}

export function addBeardVolume(head: THREE.Group, color: string, big = false) {
  const mat = std(color, 0.5, 0.05);
  addBox(head, 0.4, big ? 0.14 : 0.1, 0.07, mat, 0, -0.12, 0.185);
  [-1, 1].forEach((sx) => addBox(head, 0.05, 0.16, 0.16, mat, sx * 0.2, -0.09, 0.09));
  addSphere(head, 1, mat, 0, big ? -0.22 : -0.2, 0.2, big ? 0.14 : 0.12, big ? 0.1 : 0.075, 0.06);
}

export function addHood(head: THREE.Group, color: string) {
  const mat = std(color, 0.7, 0.03);
  const g = new THREE.Group();
  head.add(g);
  addBox(g, 0.46, 0.12, 0.44, mat, 0, 0.21, -0.02);
  addBox(g, 0.46, 0.46, 0.12, mat, 0, 0.0, -0.23);
  [-1, 1].forEach((sx) => addBox(g, 0.06, 0.4, 0.34, mat, sx * 0.22, 0.04, -0.04));
  addBox(g, 0.44, 0.06, 0.06, mat, 0, 0.16, 0.2);
  return g;
}

// ---------------------------------------------------------------------------
// Simple procedural animation for humanoid figures
// ---------------------------------------------------------------------------
export interface FigureAnimState {
  moving: boolean;
  attacking: boolean;
}

export function makeHumanoidAnimator(rig: FigureRig, opts: { stride?: number; speed?: number; baseY?: number } = {}) {
  const stride = opts.stride ?? 0.7;
  const speed = opts.speed ?? 9;
  const baseY = opts.baseY ?? 1.05;
  let t = Math.random() * 10;
  let atkT = 0;
  return (delta: number, s: FigureAnimState) => {
    t += delta;
    if (s.attacking) atkT += delta;
    else atkT = 0;

    const sw = s.moving ? Math.sin(t * speed) * stride : 0;
    rig.legL.rotation.x = sw;
    rig.legR.rotation.x = -sw;
    rig.armL.rotation.x = -sw * 0.8;
    rig.armR.rotation.x = sw * 0.8;
    rig.body.position.y = baseY + (s.moving ? Math.abs(Math.sin(t * speed)) * 0.06 : Math.sin(t * 2) * 0.012);
    rig.body.rotation.x = s.moving ? 0.1 : 0;

    if (s.attacking) {
      // overhead chop with the right arm, left arm braces
      const p = (Math.sin(atkT * 7) + 1) / 2;
      rig.armR.rotation.x = -2.2 + p * 2.6;
      rig.armL.rotation.x = -0.5;
      rig.torso.rotation.x = 0.15 * p;
    } else {
      rig.torso.rotation.x = 0;
    }
  };
}
