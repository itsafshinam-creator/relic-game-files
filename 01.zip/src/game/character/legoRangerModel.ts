import * as THREE from 'three';
import { CharacterCustomization, WeaponType } from '../../types/game';

export interface CharacterRigs {
  root: THREE.Group;
  body: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftForearm: THREE.Group;
  rightForearm: THREE.Group;
  leftHand: THREE.Group;
  rightHand: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  cape: THREE.Group;
  capeSegments: THREE.Group[];
  quiver: THREE.Group;
  backpack: THREE.Group;
  sword: THREE.Group;
  bow: THREE.Group;
  arrowInHand: THREE.Group;
  tabardFront: THREE.Group;
  materials: { [key: string]: THREE.Material };
}

// Helper to create small Lego studs on top of brick surfaces
function createStud(radius = 0.032, height = 0.02, mat: THREE.Material): THREE.Mesh {
  const geom = new THREE.CylinderGeometry(radius, radius, height, 12);
  const mesh = new THREE.Mesh(geom, mat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

// Generate high-resolution procedural face texture matching the Lego Ranger reference sheet:
// stern dark eyes, heavy straight brows, full dark beard and moustache.
function createRangerFaceTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // deterministic pseudo random (stable texture on every load)
  let seed = 1337;
  const rnd = () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };

  // Skin base with soft warm shading
  ctx.fillStyle = '#E2A87F';
  ctx.fillRect(0, 0, 512, 512);
  const skinGrad = ctx.createLinearGradient(0, 0, 0, 512);
  skinGrad.addColorStop(0, 'rgba(255,225,190,0.18)');
  skinGrad.addColorStop(1, 'rgba(150,90,60,0.22)');
  ctx.fillStyle = skinGrad;
  ctx.fillRect(0, 0, 512, 512);

  // ---- Full beard: cheeks, jaw and chin ----
  ctx.fillStyle = '#2A1B13';
  ctx.beginPath();
  ctx.moveTo(0, 300);
  ctx.quadraticCurveTo(60, 330, 110, 350);
  ctx.quadraticCurveTo(150, 372, 200, 372);
  ctx.lineTo(312, 372);
  ctx.quadraticCurveTo(362, 372, 402, 350);
  ctx.quadraticCurveTo(452, 330, 512, 300);
  ctx.lineTo(512, 512);
  ctx.lineTo(0, 512);
  ctx.closePath();
  ctx.fill();

  // Beard stubble texture (short strokes)
  ctx.strokeStyle = 'rgba(60,40,28,0.75)';
  ctx.lineWidth = 3;
  for (let i = 0; i < 520; i++) {
    const x = rnd() * 512;
    const y = 300 + rnd() * 212;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (rnd() - 0.5) * 8, y + 6 + rnd() * 8);
    ctx.stroke();
  }
  // Light stubble creeping up the cheeks
  ctx.fillStyle = 'rgba(42,27,19,0.35)';
  for (let i = 0; i < 260; i++) {
    const side = rnd() < 0.5 ? 0 : 1;
    const x = side ? 400 + rnd() * 100 : 12 + rnd() * 100;
    const y = 240 + rnd() * 90;
    ctx.fillRect(x, y, 3, 3);
  }

  // Moustache
  ctx.fillStyle = '#22150F';
  ctx.beginPath();
  ctx.moveTo(150, 345);
  ctx.quadraticCurveTo(256, 312, 362, 345);
  ctx.quadraticCurveTo(318, 388, 256, 368);
  ctx.quadraticCurveTo(194, 388, 150, 345);
  ctx.fill();

  // Mouth (a firm, slightly pressed line under the moustache)
  ctx.strokeStyle = '#7A4638';
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(222, 392);
  ctx.quadraticCurveTo(256, 398, 290, 392);
  ctx.stroke();

  // ---- Eyes & brows ----
  const drawEye = (cx: number, cy: number, flip: boolean) => {
    const dir = flip ? -1 : 1;
    ctx.save();

    // Heavy straight brow, slightly lowered on the inside (stern look)
    ctx.fillStyle = '#1A110C';
    ctx.beginPath();
    ctx.moveTo(cx - 58 * dir, cy - 52);
    ctx.lineTo(cx + 54 * dir, cy - 40);
    ctx.lineTo(cx + 52 * dir, cy - 18);
    ctx.lineTo(cx - 56 * dir, cy - 30);
    ctx.closePath();
    ctx.fill();

    // Almond eye
    ctx.fillStyle = '#F4EEE6';
    ctx.beginPath();
    ctx.moveTo(cx - 44, cy + 2);
    ctx.quadraticCurveTo(cx, cy - 34, cx + 44, cy + 2);
    ctx.quadraticCurveTo(cx, cy + 28, cx - 44, cy + 2);
    ctx.closePath();
    ctx.fill();

    // Iris (deep brown) and pupil, clipped by the eyelids
    ctx.save();
    ctx.clip();
    ctx.fillStyle = '#4A2B17';
    ctx.beginPath();
    ctx.arc(cx, cy, 25, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#0E0805';
    ctx.beginPath();
    ctx.arc(cx, cy, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(cx - 8, cy - 8, 6, 0, Math.PI * 2);
    ctx.fill();
    // upper lid shadow
    ctx.fillStyle = 'rgba(20,10,5,0.35)';
    ctx.fillRect(cx - 50, cy - 40, 100, 26);
    ctx.restore();

    // Upper lash line
    ctx.strokeStyle = '#140C08';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(cx - 46, cy + 3);
    ctx.quadraticCurveTo(cx, cy - 36, cx + 46, cy + 3);
    ctx.stroke();
    // Lower lid
    ctx.strokeStyle = 'rgba(120,70,48,0.55)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(cx - 40, cy + 6);
    ctx.quadraticCurveTo(cx, cy + 28, cx + 40, cy + 6);
    ctx.stroke();

    ctx.restore();
  };

  drawEye(160, 238, false);
  drawEye(352, 238, true);

  // Nose contour & nostril shadow
  ctx.strokeStyle = '#A8704E';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(262, 262);
  ctx.lineTo(268, 308);
  ctx.lineTo(246, 314);
  ctx.stroke();
  ctx.fillStyle = 'rgba(120,70,48,0.35)';
  ctx.beginPath();
  ctx.ellipse(256, 316, 24, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createLegoRanger(custom: CharacterCustomization = {
  capeVisible: true,
  backpackVisible: false,
  quiverVisible: true,
  weapon: 'sword',
  cowlColor: '#284638',
  sashColor: '#932029',
}): CharacterRigs {
  const root = new THREE.Group();
  root.name = 'LegoRanger';

  // Common PBR Materials with Lego glossy finish
  const matSkin = new THREE.MeshStandardMaterial({
    color: '#E5AA82',
    roughness: 0.35,
    metalness: 0.05,
  });

  const faceTexture = createRangerFaceTexture();
  const matFace = new THREE.MeshStandardMaterial({
    map: faceTexture,
    roughness: 0.35,
    metalness: 0.05,
  });

  const matHair = new THREE.MeshStandardMaterial({
    color: '#2A1A12', // Dark espresso brown
    roughness: 0.4,
    metalness: 0.1,
  });

  const matTunic = new THREE.MeshStandardMaterial({
    color: '#C6AE8A', // Buff / tan linen tunic
    roughness: 0.6,
    metalness: 0.05,
  });

  const matGreenCowl = new THREE.MeshStandardMaterial({
    color: custom.cowlColor, // Forest green mantle
    roughness: 0.55,
    metalness: 0.08,
  });

  const matCrimsonSash = new THREE.MeshStandardMaterial({
    color: custom.sashColor, // Rich crimson red sash
    roughness: 0.45,
    metalness: 0.1,
  });

  const matLeather = new THREE.MeshStandardMaterial({
    color: '#4A2E1D', // Dark leather straps & boots
    roughness: 0.5,
    metalness: 0.15,
  });

  const matLeatherDark = new THREE.MeshStandardMaterial({
    color: '#341E12',
    roughness: 0.45,
    metalness: 0.2,
  });

  const matTrousers = new THREE.MeshStandardMaterial({
    color: '#3A3F4B', // Dark grey/slate pants
    roughness: 0.55,
    metalness: 0.05,
  });

  const matSilver = new THREE.MeshStandardMaterial({
    color: '#D8DEE9',
    roughness: 0.2,
    metalness: 0.85,
  });

  const matArmorGrey = new THREE.MeshStandardMaterial({
    color: '#59606E', // Grey armour plates (thighs / shoulder)
    roughness: 0.35,
    metalness: 0.6,
  });

  const matBoot = new THREE.MeshStandardMaterial({
    color: '#5E3C22', // Warm brown boots
    roughness: 0.5,
    metalness: 0.1,
  });

  const matFeather = new THREE.MeshStandardMaterial({
    color: '#7A5535',
    roughness: 0.7,
    metalness: 0.0,
  });

  const matGoldBrass = new THREE.MeshStandardMaterial({
    color: '#D4AF37',
    roughness: 0.25,
    metalness: 0.75,
  });

  const matSteelBlade = new THREE.MeshStandardMaterial({
    color: '#E5E9F0',
    roughness: 0.15,
    metalness: 0.9,
  });

  const matWood = new THREE.MeshStandardMaterial({
    color: '#7D4F27',
    roughness: 0.6,
    metalness: 0.05,
  });

  const materials = {
    skin: matSkin,
    hair: matHair,
    tunic: matTunic,
    cowl: matGreenCowl,
    sash: matCrimsonSash,
    leather: matLeather,
    trousers: matTrousers,
    armor: matArmorGrey,
    boot: matBoot,
    silver: matSilver,
    gold: matGoldBrass,
    steel: matSteelBlade,
    wood: matWood,
  };

  // Base Body pivot
  const body = new THREE.Group();
  body.name = 'Body';
  body.position.y = 1.05; // Elevation off ground
  root.add(body);

  // -------------------------------------------------------------
  // 1. TORSO & CHEST
  // -------------------------------------------------------------
  const torso = new THREE.Group();
  torso.name = 'Torso';
  body.add(torso);

  // Main Torso Box
  const torsoGeom = new THREE.BoxGeometry(0.54, 0.58, 0.32);
  // Multi-material for front/back/sides
  const torsoMaterials = [
    matTunic, // right
    matTunic, // left
    matTunic, // top
    matTunic, // bottom
    matTunic, // front
    matTunic, // back
  ];
  const torsoMesh = new THREE.Mesh(torsoGeom, torsoMaterials);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  torso.add(torsoMesh);

  // Green Cowl / Mantle collar draped around neck & upper torso
  const cowlCollarGeom = new THREE.BoxGeometry(0.58, 0.16, 0.36);
  const cowlCollar = new THREE.Mesh(cowlCollarGeom, matGreenCowl);
  cowlCollar.position.set(0, 0.24, 0);
  cowlCollar.castShadow = true;
  torso.add(cowlCollar);

  // Studs on cowl shoulders
  [-0.22, 0.22].forEach((x) => {
    const s = createStud(0.04, 0.02, matGreenCowl);
    s.position.set(x, 0.33, 0);
    torso.add(s);
  });

  // Silver circular Medallion / Brooch on left chest collar
  const medallionGeom = new THREE.CylinderGeometry(0.065, 0.065, 0.02, 16);
  const medallion = new THREE.Mesh(medallionGeom, matSilver);
  medallion.rotation.x = Math.PI / 2;
  medallion.position.set(0.16, 0.22, 0.19);
  medallion.castShadow = true;
  torso.add(medallion);

  // Inner Gold stud inside medallion
  const innerPin = createStud(0.022, 0.015, matGoldBrass);
  innerPin.rotation.x = Math.PI / 2;
  innerPin.position.set(0.16, 0.22, 0.205);
  torso.add(innerPin);

  // Crimson X cross-straps over the tunic (as on the reference sheet)
  [-0.6, 0.6].forEach((rot) => {
    const crimson = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.66, 0.035), matCrimsonSash);
    crimson.rotation.z = rot;
    crimson.position.set(0, 0.0, 0.172);
    crimson.castShadow = true;
    torso.add(crimson);
    // thin dark leather edge stitched on the strap
    const edge = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.66, 0.04), matLeatherDark);
    edge.rotation.z = rot;
    edge.position.set(0, 0.0, 0.175);
    torso.add(edge);
  });

  // Small brass rivet where the straps cross
  const crossRivet = createStud(0.028, 0.02, matGoldBrass);
  crossRivet.rotation.x = Math.PI / 2;
  crossRivet.position.set(0, 0.0, 0.196);
  torso.add(crossRivet);

  // Leather Utility Belt around waist
  const beltGeom = new THREE.BoxGeometry(0.56, 0.11, 0.34);
  const beltMesh = new THREE.Mesh(beltGeom, matLeatherDark);
  beltMesh.position.set(0, -0.25, 0);
  beltMesh.castShadow = true;
  torso.add(beltMesh);

  // Belt Buckle (Brass rectangular plate)
  const buckleGeom = new THREE.BoxGeometry(0.12, 0.09, 0.03);
  const buckleMesh = new THREE.Mesh(buckleGeom, matGoldBrass);
  buckleMesh.position.set(0, -0.25, 0.18);
  torso.add(buckleMesh);

  // Belt Ring Accessory (Gold ring on left waist)
  const ringGeom = new THREE.TorusGeometry(0.04, 0.012, 8, 16);
  const ringMesh = new THREE.Mesh(ringGeom, matGoldBrass);
  ringMesh.position.set(-0.16, -0.27, 0.18);
  torso.add(ringMesh);

  // Belt pouches & utility loops
  [[0.21, 0.172, 0.10, 0.12], [-0.24, 0.168, 0.09, 0.10]].forEach(([px, pz, pw, ph], i) => {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(pw, ph, 0.07), matLeather);
    pouch.position.set(px, -0.35, pz + 0.01);
    pouch.castShadow = true;
    torso.add(pouch);
    const flap = new THREE.Mesh(new THREE.BoxGeometry(pw + 0.01, 0.035, 0.075), matLeatherDark);
    flap.position.set(px, -0.35 + ph / 2 - 0.012, pz + 0.012);
    torso.add(flap);
    const snap = createStud(0.014, 0.012, matGoldBrass);
    snap.rotation.x = Math.PI / 2;
    snap.position.set(px, -0.35 + ph / 2 - 0.012, pz + 0.055);
    torso.add(snap);
    void i;
  });

  // Hanging Crimson Tabard / Cloth flap hanging in front between thighs
  const tabardFront = new THREE.Group();
  tabardFront.name = 'TabardFront';
  tabardFront.position.set(0, -0.3, 0.17);
  // Layered tattered brick cloth segments
  const tabardUpperGeom = new THREE.BoxGeometry(0.17, 0.30, 0.03);
  const tabardUpper = new THREE.Mesh(tabardUpperGeom, matCrimsonSash);
  tabardUpper.position.y = -0.15;
  tabardUpper.castShadow = true;
  tabardFront.add(tabardUpper);

  // Stepped lower ragged brick edge
  const tabardLowerGeom = new THREE.BoxGeometry(0.13, 0.17, 0.028);
  const tabardLower = new THREE.Mesh(tabardLowerGeom, matCrimsonSash);
  tabardLower.position.set(0.012, -0.38, 0);
  tabardLower.castShadow = true;
  tabardFront.add(tabardLower);

  torso.add(tabardFront);

  // -------------------------------------------------------------
  // 2. HEAD, FACE & BLOCKY HAIR
  // -------------------------------------------------------------
  const head = new THREE.Group();
  head.name = 'Head';
  head.position.set(0, 0.44, 0);
  body.add(head);

  // Head cube
  const headGeom = new THREE.BoxGeometry(0.38, 0.38, 0.36);
  const headMaterials = [
    matSkin, // right
    matSkin, // left
    matSkin, // top
    matSkin, // bottom
    matFace, // front (Face texture with eyes, beard, stubble)
    matHair, // back (covered by hair)
  ];
  const headMesh = new THREE.Mesh(headGeom, headMaterials);
  headMesh.castShadow = true;
  headMesh.receiveShadow = true;
  head.add(headMesh);

  // Ears (Small skin boxes on sides)
  [-0.20, 0.20].forEach((x) => {
    const ear = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.09, 0.07), matSkin);
    ear.position.set(x, 0.02, -0.01);
    head.add(ear);
  });

  // Hair Group: thick curly dark hair built from overlapping curl blobs
  const hairGroup = new THREE.Group();
  hairGroup.name = 'LegoHair';
  head.add(hairGroup);

  // Solid base so no skin shows between the curls
  const hairCap = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.13, 0.40), matHair);
  hairCap.position.set(0, 0.17, -0.01);
  hairCap.castShadow = true;
  hairGroup.add(hairCap);
  const hairBackMass = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.34, 0.12), matHair);
  hairBackMass.position.set(0, 0.03, -0.2);
  hairBackMass.castShadow = true;
  hairGroup.add(hairBackMass);
  [-1, 1].forEach((sx) => {
    const sideMass = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.26), matHair);
    sideMass.position.set(sx * 0.2, 0.08, -0.06);
    hairGroup.add(sideMass);
  });

  const curlGeom = new THREE.SphereGeometry(1, 9, 7);
  let curlSeed = 42;
  const curlRnd = () => {
    curlSeed = (curlSeed * 16807) % 2147483647;
    return curlSeed / 2147483647;
  };
  const addCurl = (x: number, y: number, z: number, r: number) => {
    const curl = new THREE.Mesh(curlGeom, matHair);
    const j = 0.012;
    curl.position.set(x + (curlRnd() - 0.5) * j * 2, y + (curlRnd() - 0.5) * j * 2, z + (curlRnd() - 0.5) * j * 2);
    const sc = r * (0.9 + curlRnd() * 0.25);
    curl.scale.set(sc, sc * (0.9 + curlRnd() * 0.2), sc);
    curl.castShadow = true;
    hairGroup.add(curl);
  };
  // Crown (two stacked layers of curls)
  [-0.15, -0.05, 0.05, 0.15].forEach((x) => {
    [-0.15, -0.05, 0.05, 0.15].forEach((z) => addCurl(x, 0.25, z, 0.075));
  });
  [-0.09, 0.09].forEach((x) => [-0.08, 0.08].forEach((z) => addCurl(x, 0.31, z, 0.065)));
  // Fringe curls hanging above the brows
  [-0.16, -0.08, 0, 0.08, 0.16].forEach((x, i) => addCurl(x, 0.17 - (i % 2) * 0.012, 0.19, 0.06));
  // Temple / side curls (leave the ears visible-ish)
  [-1, 1].forEach((sx) => {
    [-0.14, -0.02, 0.1].forEach((z) => {
      [0.15, 0.05, -0.05].forEach((y) => addCurl(sx * 0.21, y, z, 0.065));
    });
  });
  // Back of head curls cascading down the neck
  [-0.16, -0.055, 0.055, 0.16].forEach((x) => {
    [0.2, 0.1, 0.0, -0.08].forEach((y, row) => addCurl(x * (row > 2 ? 0.85 : 1), y, -0.22, row > 2 ? 0.065 : 0.08));
  });

  // Full beard volume: jaw wrap + chin (texture adds the stubble on the face itself)
  const beardJaw = new THREE.Mesh(new THREE.BoxGeometry(0.40, 0.11, 0.07), matHair);
  beardJaw.position.set(0, -0.12, 0.185);
  beardJaw.castShadow = true;
  hairGroup.add(beardJaw);
  [-1, 1].forEach((sx) => {
    const cheekBeard = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.16), matHair);
    cheekBeard.position.set(sx * 0.2, -0.09, 0.09);
    hairGroup.add(cheekBeard);
  });
  const beardChin = new THREE.Mesh(curlGeom, matHair);
  beardChin.scale.set(0.12, 0.075, 0.06);
  beardChin.position.set(0, -0.195, 0.2);
  beardChin.castShadow = true;
  hairGroup.add(beardChin);
  const beardChin2 = new THREE.Mesh(curlGeom, matHair);
  beardChin2.scale.set(0.07, 0.06, 0.05);
  beardChin2.position.set(0, -0.24, 0.185);
  hairGroup.add(beardChin2);

  // -------------------------------------------------------------
  // 3. CAPE / CLOAK (Tiered dynamic brick cloth drape)
  // -------------------------------------------------------------
  const cape = new THREE.Group();
  cape.name = 'Cape';
  cape.position.set(0, 0.22, -0.215);
  torso.add(cape);

  const capeSegments: THREE.Group[] = [];

  // Segment 1 (Top shoulder cape)
  const capeSeg1 = new THREE.Group();
  const capeMesh1 = new THREE.Mesh(new THREE.BoxGeometry(0.60, 0.30, 0.04), matGreenCowl);
  capeMesh1.position.set(0, -0.14, 0);
  capeMesh1.castShadow = true;
  capeSeg1.add(capeMesh1);
  cape.add(capeSeg1);
  capeSegments.push(capeSeg1);

  // Segment 2 (Mid back cape)
  const capeSeg2 = new THREE.Group();
  capeSeg2.position.set(0, -0.28, 0);
  const capeMesh2 = new THREE.Mesh(new THREE.BoxGeometry(0.64, 0.32, 0.038), matGreenCowl);
  capeMesh2.position.set(0, -0.15, 0);
  capeMesh2.castShadow = true;
  capeSeg2.add(capeMesh2);
  capeSeg1.add(capeSeg2);
  capeSegments.push(capeSeg2);

  // Segment 3 (Lower tattered frayed cape with ragged stepped cutouts)
  const capeSeg3 = new THREE.Group();
  capeSeg3.position.set(0, -0.30, 0);
  const capeMesh3 = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.36, 0.035), matGreenCowl);
  capeMesh3.position.set(0, -0.17, 0);
  capeMesh3.castShadow = true;
  capeSeg3.add(capeMesh3);

  // Bottom ragged fringes (Lego jagged cut blocks)
  const fringe1 = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.18, 0.03), matGreenCowl);
  fringe1.position.set(-0.22, -0.40, 0);
  capeSeg3.add(fringe1);

  const fringe2 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.26, 0.03), matGreenCowl);
  fringe2.position.set(0.04, -0.44, 0);
  capeSeg3.add(fringe2);

  const fringe3 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.15, 0.03), matGreenCowl);
  fringe3.position.set(0.24, -0.38, 0);
  capeSeg3.add(fringe3);

  capeSeg2.add(capeSeg3);
  capeSegments.push(capeSeg3);

  cape.visible = custom.capeVisible;

  // -------------------------------------------------------------
  // 4. ARMS, PAULDRONS & HANDS
  // -------------------------------------------------------------
  // Left Arm (Bow holding arm / off-hand)
  const leftArm = new THREE.Group();
  leftArm.name = 'LeftArm';
  leftArm.position.set(-0.35, 0.18, 0);
  body.add(leftArm);

  // Left Pauldron (Leather/metal shoulder guard)
  const pauldronL = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.12, 0.20), matArmorGrey);
  pauldronL.position.set(0, 0.03, 0);
  const pauldronLRim = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.03, 0.22), matSilver);
  pauldronLRim.position.set(0, -0.03, 0);
  leftArm.add(pauldronLRim);
  pauldronL.castShadow = true;
  leftArm.add(pauldronL);
  // Stud on shoulder
  const pStudL = createStud(0.04, 0.02, matSilver);
  pStudL.position.set(0, 0.10, 0);
  leftArm.add(pStudL);

  // Left Upper Arm
  const upperArmL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.22, 0.14), matSkin);
  upperArmL.position.set(0, -0.10, 0);
  upperArmL.castShadow = true;
  leftArm.add(upperArmL);

  // Left Forearm
  const leftForearm = new THREE.Group();
  leftForearm.name = 'LeftForearm';
  leftForearm.position.set(0, -0.22, 0);
  leftArm.add(leftForearm);

  // Left Leather Bracer / Vambrace with studs
  const bracerL = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.22, 0.15), matLeather);
  bracerL.position.set(0, -0.10, 0);
  bracerL.castShadow = true;
  leftForearm.add(bracerL);
  // Mini studs on forearm bracer
  [-0.04, 0.04].forEach((yOffset) => {
    const bs = createStud(0.022, 0.015, matSilver);
    bs.rotation.x = Math.PI / 2;
    bs.position.set(0, -0.10 + yOffset, 0.08);
    leftForearm.add(bs);
  });

  // Left Hand (Cupped Lego C-Hand in dark leather glove)
  const leftHand = new THREE.Group();
  leftHand.name = 'LeftHand';
  leftHand.position.set(0, -0.24, 0);
  leftForearm.add(leftHand);

  const handGeom = new THREE.CylinderGeometry(0.065, 0.065, 0.09, 16, 1, false, 0, Math.PI * 1.6);
  const handMeshL = new THREE.Mesh(handGeom, matLeatherDark);
  handMeshL.rotation.z = Math.PI / 2;
  handMeshL.castShadow = true;
  leftHand.add(handMeshL);

  // -------------------------------------------------------------
  // Right Arm (Sword swinging / bowstring drawing arm)
  // -------------------------------------------------------------
  const rightArm = new THREE.Group();
  rightArm.name = 'RightArm';
  rightArm.position.set(0.35, 0.18, 0);
  body.add(rightArm);

  // Right Pauldron
  const pauldronR = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 0.16), matLeatherDark);
  pauldronR.position.set(0, 0, 0);
  pauldronR.castShadow = true;
  rightArm.add(pauldronR);
  const pStudR = createStud(0.03, 0.018, matSilver);
  pStudR.position.set(0, 0.09, 0);
  rightArm.add(pStudR);

  // Right Upper Arm
  const upperArmR = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.22, 0.14), matSkin);
  upperArmR.position.set(0, -0.10, 0);
  upperArmR.castShadow = true;
  rightArm.add(upperArmR);

  // Right Forearm
  const rightForearm = new THREE.Group();
  rightForearm.name = 'RightForearm';
  rightForearm.position.set(0, -0.22, 0);
  rightArm.add(rightForearm);

  const bracerR = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.22, 0.15), matLeather);
  bracerR.position.set(0, -0.10, 0);
  bracerR.castShadow = true;
  rightForearm.add(bracerR);
  [-0.04, 0.04].forEach((yOffset) => {
    const bs = createStud(0.022, 0.015, matSilver);
    bs.rotation.x = Math.PI / 2;
    bs.position.set(0, -0.10 + yOffset, 0.08);
    rightForearm.add(bs);
  });

  // Right Hand
  const rightHand = new THREE.Group();
  rightHand.name = 'RightHand';
  rightHand.position.set(0, -0.24, 0);
  rightForearm.add(rightHand);

  const handMeshR = new THREE.Mesh(handGeom.clone(), matLeatherDark);
  handMeshR.rotation.z = Math.PI / 2;
  handMeshR.castShadow = true;
  rightHand.add(handMeshR);

  // -------------------------------------------------------------
  // 5. LEGS & STUDDED GREAVES / BOOTS
  // -------------------------------------------------------------
  // Left Leg
  const leftLeg = new THREE.Group();
  leftLeg.name = 'LeftLeg';
  leftLeg.position.set(-0.15, -0.32, 0);
  body.add(leftLeg);

  // Upper Leg / Trousers
  const legUpperL = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.32, 0.22), matTrousers);
  legUpperL.position.set(0, -0.16, 0);
  legUpperL.castShadow = true;
  leftLeg.add(legUpperL);

  // Grey thigh armour plate + knee guard
  const thighPlateL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.18, 0.04), matArmorGrey);
  thighPlateL.position.set(0, -0.10, 0.125);
  thighPlateL.castShadow = true;
  leftLeg.add(thighPlateL);
  const kneeGuardL = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.07, 0.05), matLeatherDark);
  kneeGuardL.position.set(0, -0.31, 0.12);
  leftLeg.add(kneeGuardL);

  // Boot & Greave
  const bootL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.34, 0.24), matBoot);
  bootL.position.set(0, -0.48, 0);
  bootL.castShadow = true;
  leftLeg.add(bootL);
  const bootCuffL = new THREE.Mesh(new THREE.BoxGeometry(0.245, 0.07, 0.265), matLeatherDark);
  bootCuffL.position.set(0, -0.34, 0);
  leftLeg.add(bootCuffL);
  [-0.44, -0.54].forEach((by) => {
    const strap = new THREE.Mesh(new THREE.BoxGeometry(0.235, 0.03, 0.255), matLeatherDark);
    strap.position.set(0, by, 0);
    leftLeg.add(strap);
  });

  // Boot Sole & Toe Extension
  const toeL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.12, 0.12), matLeatherDark);
  toeL.position.set(0, -0.59, 0.08);
  toeL.castShadow = true;
  leftLeg.add(toeL);

  // Shin Studs (Lego Studded greaves as seen in photo!)
  [-0.40, -0.48, -0.56].forEach((y) => {
    [-0.05, 0.05].forEach((x) => {
      const s = createStud(0.028, 0.018, matLeather);
      s.rotation.x = Math.PI / 2;
      s.position.set(x, y, 0.13);
      leftLeg.add(s);
    });
  });

  // Right Leg
  const rightLeg = new THREE.Group();
  rightLeg.name = 'RightLeg';
  rightLeg.position.set(0.15, -0.32, 0);
  body.add(rightLeg);

  const legUpperR = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.32, 0.22), matTrousers);
  legUpperR.position.set(0, -0.16, 0);
  legUpperR.castShadow = true;
  rightLeg.add(legUpperR);

  // Grey thigh armour plate + knee guard
  const thighPlateR = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.18, 0.04), matArmorGrey);
  thighPlateR.position.set(0, -0.10, 0.125);
  thighPlateR.castShadow = true;
  rightLeg.add(thighPlateR);
  const kneeGuardR = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.07, 0.05), matLeatherDark);
  kneeGuardR.position.set(0, -0.31, 0.12);
  rightLeg.add(kneeGuardR);

  const bootR = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.34, 0.24), matBoot);
  bootR.position.set(0, -0.48, 0);
  bootR.castShadow = true;
  rightLeg.add(bootR);
  const bootCuffR = new THREE.Mesh(new THREE.BoxGeometry(0.245, 0.07, 0.265), matLeatherDark);
  bootCuffR.position.set(0, -0.34, 0);
  rightLeg.add(bootCuffR);
  [-0.44, -0.54].forEach((by) => {
    const strap = new THREE.Mesh(new THREE.BoxGeometry(0.235, 0.03, 0.255), matLeatherDark);
    strap.position.set(0, by, 0);
    rightLeg.add(strap);
  });

  const toeR = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.12, 0.12), matLeatherDark);
  toeR.position.set(0, -0.59, 0.08);
  toeR.castShadow = true;
  rightLeg.add(toeR);

  [-0.40, -0.48, -0.56].forEach((y) => {
    [-0.05, 0.05].forEach((x) => {
      const s = createStud(0.028, 0.018, matLeather);
      s.rotation.x = Math.PI / 2;
      s.position.set(x, y, 0.13);
      rightLeg.add(s);
    });
  });

  // -------------------------------------------------------------
  // 6. BACK QUIVER & ARROWS
  // -------------------------------------------------------------
  const quiver = new THREE.Group();
  quiver.name = 'Quiver';
  quiver.position.set(-0.16, 0.12, -0.22);
  quiver.rotation.z = 0.42; // Slung diagonally across back
  torso.add(quiver);

  // Quiver Body (Hexagonal/Cylinder leather sheath)
  const quiverGeom = new THREE.CylinderGeometry(0.075, 0.06, 0.58, 8);
  const quiverMesh = new THREE.Mesh(quiverGeom, matLeather);
  quiverMesh.castShadow = true;
  quiver.add(quiverMesh);

  // Studs on quiver
  for (let i = -0.2; i <= 0.2; i += 0.1) {
    const qs = createStud(0.018, 0.012, matGoldBrass);
    qs.position.set(0, i, 0.065);
    quiver.add(qs);
  }

  // Arrows poking out from quiver
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const arrowShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.35, 6), matWood);
    arrowShaft.position.set(Math.cos(angle) * 0.035, 0.36 + (i % 2) * 0.06, Math.sin(angle) * 0.035);
    arrowShaft.castShadow = true;
    quiver.add(arrowShaft);

    // Fletching feathers
    const fletching = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.09, 0.008), matFeather);
    fletching.position.set(Math.cos(angle) * 0.035, 0.46 + (i % 2) * 0.06, Math.sin(angle) * 0.035);
    quiver.add(fletching);
  }

  quiver.visible = custom.quiverVisible;

  // -------------------------------------------------------------
  // 7. ADVENTURER BACKPACK (Toggleable cosmetic)
  // -------------------------------------------------------------
  const backpack = new THREE.Group();
  backpack.name = 'Backpack';
  backpack.position.set(0, 0.02, -0.25);
  torso.add(backpack);

  // Main Bag Pack
  const packBase = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.38, 0.20), matLeather);
  packBase.castShadow = true;
  backpack.add(packBase);

  // Rolled Bedroll on top
  const bedroll = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.40, 12), matLeatherDark);
  bedroll.rotation.z = Math.PI / 2;
  bedroll.position.set(0, 0.24, 0);
  bedroll.castShadow = true;
  backpack.add(bedroll);

  // Lantern on side
  const lantern = new THREE.Group();
  lantern.position.set(-0.21, -0.05, 0);
  const lanternBody = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.12, 8), matGoldBrass);
  lantern.add(lanternBody);
  const lanternGlow = new THREE.Mesh(
    new THREE.SphereGeometry(0.03, 8, 8),
    new THREE.MeshBasicMaterial({ color: '#FEF08A' })
  );
  lantern.add(lanternGlow);
  backpack.add(lantern);

  backpack.visible = custom.backpackVisible;

  // -------------------------------------------------------------
  // 8. WEAPONS (Sword & Recurve Bow)
  // -------------------------------------------------------------
  // Fantasy Brick Sword
  const sword = new THREE.Group();
  sword.name = 'BrickSword';

  // Blade with double bevel
  const bladeGeom = new THREE.BoxGeometry(0.09, 0.85, 0.024);
  const blade = new THREE.Mesh(bladeGeom, matSteelBlade);
  blade.position.y = 0.45;
  blade.castShadow = true;
  sword.add(blade);

  // Blade Tip (triangular point)
  const tipGeom = new THREE.ConeGeometry(0.065, 0.16, 4);
  const tip = new THREE.Mesh(tipGeom, matSteelBlade);
  tip.position.y = 0.94;
  tip.rotation.y = Math.PI / 4;
  tip.castShadow = true;
  sword.add(tip);

  // Central Fuller Groove
  const fullerGeom = new THREE.BoxGeometry(0.022, 0.65, 0.028);
  const fuller = new THREE.Mesh(fullerGeom, matSilver);
  fuller.position.y = 0.42;
  sword.add(fuller);

  // Winged Crossguard (Bronze/Brass)
  const guardGeom = new THREE.BoxGeometry(0.28, 0.055, 0.06);
  const guard = new THREE.Mesh(guardGeom, matSilver);
  guard.position.y = 0.03;
  guard.castShadow = true;
  sword.add(guard);

  // Guard studs
  [-0.11, 0.11].forEach((x) => {
    const gs = createStud(0.02, 0.015, matGoldBrass);
    gs.position.set(x, 0.03, 0.035);
    sword.add(gs);
  });

  // Hilt Grip
  const hiltGeom = new THREE.CylinderGeometry(0.028, 0.028, 0.18, 12);
  const hilt = new THREE.Mesh(hiltGeom, new THREE.MeshStandardMaterial({ color: '#17120F', roughness: 0.5 }));
  hilt.position.y = -0.09;
  sword.add(hilt);

  // Pommel
  const pommelGeom = new THREE.DodecahedronGeometry(0.045);
  const pommel = new THREE.Mesh(pommelGeom, matSilver);
  pommel.position.y = -0.20;
  pommel.castShadow = true;
  sword.add(pommel);

  // Attached to Right Hand by default
  sword.position.set(0, -0.06, 0.08);
  sword.rotation.x = Math.PI / 2;
  rightHand.add(sword);

  // Recurve Bow
  const bow = new THREE.Group();
  bow.name = 'RecurveBow';

  // Curved stave created via connected segments
  const bowSegments: THREE.Mesh[] = [];
  const numBowSegs = 9;
  for (let i = 0; i < numBowSegs; i++) {
    const t = (i / (numBowSegs - 1)) * 2 - 1; // -1 to 1
    const seg = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.13, 0.04), matWood);
    const curveZ = (1 - t * t) * 0.16; // Curve shape
    seg.position.set(0, t * 0.52, curveZ);
    seg.rotation.x = -t * 0.45;
    seg.castShadow = true;
    bow.add(seg);
    bowSegments.push(seg);
  }

  // Bowstring
  const stringGeom = new THREE.CylinderGeometry(0.005, 0.005, 1.05, 6);
  const bowString = new THREE.Mesh(stringGeom, new THREE.MeshBasicMaterial({ color: '#E2E8F0' }));
  bowString.position.set(0, 0, 0);
  bow.add(bowString);

  // Bow attached to Left Hand
  bow.position.set(0, 0, 0.08);
  bow.rotation.y = Math.PI / 2;
  bow.rotation.z = Math.PI;
  leftHand.add(bow);

  // Arrow in Hand (for bow aim animation)
  const arrowInHand = new THREE.Group();
  arrowInHand.name = 'ArrowInHand';
  const arrowShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.9, 6), matWood);
  arrowShaft.position.z = 0.45;
  arrowShaft.rotation.x = Math.PI / 2;
  arrowInHand.add(arrowShaft);

  const arrowhead = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.1, 4), matSilver);
  arrowhead.position.z = 0.92;
  arrowhead.rotation.x = Math.PI / 2;
  arrowInHand.add(arrowhead);

  arrowInHand.visible = false;
  rightHand.add(arrowInHand);

  // Set initial weapon visibility
  if (custom.weapon === 'bow') {
    sword.visible = false;
    bow.visible = true;
  } else {
    sword.visible = true;
    bow.visible = false;
  }

  return {
    root,
    body,
    head,
    torso,
    leftArm,
    rightArm,
    leftForearm,
    rightForearm,
    leftHand,
    rightHand,
    leftLeg,
    rightLeg,
    cape,
    capeSegments,
    quiver,
    backpack,
    sword,
    bow,
    arrowInHand,
    tabardFront,
    materials,
  };
}
