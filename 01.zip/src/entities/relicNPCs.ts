import * as THREE from 'three';
import { NPCData } from '../types/relic';
import { sounds } from '../audio/soundSystem';
import {
  FigureRig,
  addBeardVolume,
  addBox,
  addCyl,
  addHood,
  addShortHair,
  addSphere,
  addStud,
  enableShadows,
  makeFaceTexture,
  makeFigure,
  std,
} from '../game/character/legoFigures';

export interface RelicNPCManager {
  npcs: NPCData[];
  update: (delta: number, playerPos: THREE.Vector3) => void;
  getNearbyNPC: (playerPos: THREE.Vector3, range?: number) => NPCData | null;
  /** The NPC currently in a conversation (plays talking gestures), or null. */
  setTalking: (id: string | null) => void;
}

export function buildRelicNPCs(scene: THREE.Scene): RelicNPCManager {
  const npcs: NPCData[] = [];
  const steel = new THREE.MeshStandardMaterial({ color: '#8E99AB', roughness: 0.25, metalness: 0.85 });
  const brass = new THREE.MeshStandardMaterial({ color: '#D4AF37', roughness: 0.25, metalness: 0.75 });
  const wood = std('#7D4F27', 0.6, 0.05);
  const leather = std('#4A2E1D', 0.5, 0.15);
  const leatherDark = std('#341E12', 0.45, 0.2);

  // ---------------------------------------------------------------
  // NPC animation: idle life, greeting wave, and talking gestures that
  // pulse in time with the babble voice while the dialogue types out.
  // ---------------------------------------------------------------
  interface NpcAnim {
    id: string;
    voice: string;
    rig: FigureRig;
    phase: number;
    free: 'L' | 'R' | null; // arm that is free to wave / gesture
    baseL: number;
    baseR: number;
    extra?: (t: number, rig: FigureRig, busy: boolean) => void;
    wasNear: boolean;
    greet: number;
    nod: number;
  }
  const anims: NpcAnim[] = [];
  let talkingId: string | null = null;

  const registerNPC = (a: Omit<NpcAnim, 'wasNear' | 'greet' | 'nod'>) => {
    anims.push({ ...a, wasNear: false, greet: 0, nod: 0 });
  };

  const animateNPC = (a: NpcAnim, t: number, delta: number, playerPos: THREE.Vector3) => {
    const rig = a.rig;
    const dx = playerPos.x - rig.root.position.x;
    const dz = playerPos.z - rig.root.position.z;
    const near = Math.sqrt(dx * dx + dz * dz) < 5;
    const talking = talkingId === a.id;
    if (near && !a.wasNear && a.free && !talking) a.greet = 1.9;
    a.wasNear = near;
    a.greet = Math.max(0, a.greet - delta);

    const speaking = talking && performance.now() - sounds.lastSpeech.time < 230 && sounds.lastSpeech.voice === a.voice;
    a.nod += ((speaking ? 1 : 0) - a.nod) * Math.min(1, delta * 16);

    // --- base idle: breathing, weight shift, arm sway ---
    const s = Math.sin(t * 2 + a.phase);
    rig.body.position.y = 1.05 + s * 0.012;
    rig.body.rotation.z = Math.sin(t * 0.8 + a.phase) * 0.02;
    rig.torso.rotation.set(0, 0, 0);
    rig.armL.rotation.set(a.baseL + s * 0.04, 0, 0.08);
    rig.armR.rotation.set(a.baseR + s * 0.04, 0, -0.08);
    rig.foreL.rotation.set(0, 0, 0);
    rig.foreR.rotation.set(0, 0, 0);
    rig.legL.rotation.x = 0;
    rig.legR.rotation.x = 0;

    // head: look around when alone, watch the hero when near, nod while talking
    if (talking) {
      rig.head.rotation.y = Math.sin(t * 1.3 + a.phase) * 0.07;
      rig.head.rotation.x = -0.03 + a.nod * (0.1 + 0.1 * Math.sin(t * 24)) + Math.sin(t * 2.1) * 0.02;
    } else if (near) {
      rig.head.rotation.set(0, Math.sin(t * 0.9 + a.phase) * 0.1, 0);
    } else {
      rig.head.rotation.set(Math.sin(t * 0.7 + a.phase) * 0.03, Math.sin(t * 0.45 + a.phase) * 0.5, 0);
    }

    a.extra?.(t, rig, near || talking);

    // --- talking gestures (free arm, or the torso for armed guards) ---
    if (talking) {
      const amp = 0.35 + a.nod * 0.55;
      rig.torso.rotation.y = Math.sin(t * 1.7) * 0.08;
      rig.torso.rotation.x = a.nod * 0.05;
      if (a.free) {
        const arm = a.free === 'L' ? rig.armL : rig.armR;
        const fore = a.free === 'L' ? rig.foreL : rig.foreR;
        arm.rotation.x = -0.95 + Math.sin(t * 4.2) * amp * 0.45;
        arm.rotation.z = (a.free === 'L' ? -1 : 1) * (0.18 + Math.sin(t * 2.6) * 0.12);
        fore.rotation.x = -0.75 + Math.sin(t * 5.3) * 0.25 * amp;
      }
    } else if (a.greet > 0 && a.free) {
      // greeting wave
      const arm = a.free === 'L' ? rig.armL : rig.armR;
      const fore = a.free === 'L' ? rig.foreL : rig.foreR;
      const dir = a.free === 'L' ? -1 : 1;
      const rise = Math.min(1, (1.9 - a.greet) / 0.3);
      const fall = Math.min(1, a.greet / 0.3);
      const p = Math.min(rise, fall);
      arm.rotation.x = -2.45 * p;
      arm.rotation.z = dir * 0.3 * p;
      fore.rotation.z = dir * Math.sin(t * 13) * 0.5 * p;
    }
  };

  // 1. Mara - hooded Seeker Lorekeeper by the campfire
  function spawnMara(x: number, z: number) {
    const robe = std('#1E3A2F', 0.7, 0.03);
    const trim = std('#C9A24B', 0.4, 0.6);
    const rig = makeFigure({
      skin: '#E8B48C',
      torso: robe,
      pants: '#1E3A2F',
      boots: '#3A2616',
      sleeve: '#1E3A2F',
      bracer: '#C9A24B',
      glove: '#3A2616',
      face: makeFaceTexture('human', { skin: '#E8B48C', soft: true, iris: '#3B6A8C', browColor: '#6B7280' }),
    });
    addHood(rig.head, '#1E3A2F');
    // silver hair framing the face
    const silver = std('#CBD5E1', 0.45, 0.2);
    [-1, 1].forEach((sx) => addBox(rig.head, 0.05, 0.3, 0.08, silver, sx * 0.19, -0.08, 0.15));
    addBox(rig.head, 0.4, 0.05, 0.05, silver, 0, 0.16, 0.2);
    // robe skirt (covers the legs) with gold trim
    addBox(rig.body, 0.64, 0.55, 0.4, robe, 0, -0.5, 0);
    addBox(rig.body, 0.66, 0.06, 0.42, trim, 0, -0.76, 0);
    addBox(rig.torso, 0.56, 0.05, 0.34, trim, 0, 0.27, 0);
    addBox(rig.torso, 0.12, 0.56, 0.02, trim, 0, 0, 0.17);
    // crystal pendant
    addSphere(rig.torso, 0.04, new THREE.MeshBasicMaterial({ color: '#38BDF8' }), 0, 0.18, 0.19, 0.8, 1.3, 0.8);
    // satchel
    addBox(rig.torso, 0.1, 0.5, 0.02, leather, -0.02, 0.0, 0.17).rotation.z = 0.6;
    addBox(rig.torso, 0.2, 0.18, 0.1, leatherDark, 0.22, -0.28, 0.1);
    // walking staff with glowing orb
    addCyl(rig.handR, 0.03, 0.03, 1.9, wood, 0, 0.5, 0.0, 8);
    const orbMat = new THREE.MeshBasicMaterial({ color: '#38BDF8' });
    const orb = addSphere(rig.handR, 0.09, orbMat, 0, 1.5, 0);
    addSphere(rig.handR, 0.15, new THREE.MeshBasicMaterial({ color: '#7DD3FC', transparent: true, opacity: 0.25 }), 0, 1.5, 0);
    addStud(rig.handR, brass, 0, 1.38, 0, 0.06, 0.04);
    rig.armR.rotation.x = -0.1;

    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    registerNPC({
      id: 'npc_mara',
      voice: 'mara',
      rig,
      phase: 0.3,
      free: 'L',
      baseL: 0.05,
      baseR: -0.1,
      extra: (t, r) => {
        orb.scale.setScalar(1 + Math.sin(t * 3) * 0.12 + Math.sin(t * 7) * 0.03);
        orb.position.y = 1.5 + Math.sin(t * 1.6) * 0.03;
        r.armR.rotation.z = -0.08 + Math.sin(t * 0.9) * 0.05; // staff sways
      },
    });

    npcs.push({
      id: 'npc_mara',
      type: 'mara',
      name: 'Mara',
      title: 'Seeker Lorekeeper',
      position: { x, y: 0, z },
      rotation: 0,
      dialogue: [
        'Greetings, Seeker. The lost world is waking once more.',
        'To the north lies the Ancient Temple. Deep within sits the divine Relic Shard.',
        'Collect 3 Wood and 2 Iron first, and consult Toren the Blacksmith to prepare for the Dungeon Guardian!',
      ],
      mesh: rig.root,
    });
  }

  // 2. Toren - bearded Master Blacksmith by the forge
  function spawnToren(x: number, z: number) {
    const tunic = std('#6B4426', 0.65, 0.05);
    const rig = makeFigure({
      skin: '#D99A6C',
      torso: tunic,
      pants: '#3B3430',
      boots: '#4A2E1D',
      sleeve: null, // bare, muscular arms
      bracer: '#2B1A10',
      glove: '#2B1A10',
      armW: 1.18,
      torsoW: 1.1,
      face: makeFaceTexture('human', { skin: '#D99A6C', beard: 'bushy', beardColor: '#8A4B1E', browColor: '#6B3416', iris: '#3A2A18', scar: true }),
    });
    addBeardVolume(rig.head, '#8A4B1E', true);
    addShortHair(rig.head, '#8A4B1E');
    // goggles pushed up on the forehead
    [-0.09, 0.09].forEach((gx) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.02, 8, 14), brass);
      ring.position.set(gx, 0.17, 0.19);
      rig.head.add(ring);
      addCyl(rig.head, 0.05, 0.05, 0.02, std('#7DD3FC', 0.1, 0.1), gx, 0.17, 0.195, 12).rotation.x = Math.PI / 2;
    });
    addBox(rig.head, 0.42, 0.04, 0.4, leatherDark, 0, 0.17, -0.0);
    // leather apron + straps
    const apron = std('#78350F', 0.65, 0.05);
    addBox(rig.torso, 0.46, 0.7, 0.04, apron, 0, -0.08, 0.18);
    addBox(rig.torso, 0.08, 0.34, 0.02, leatherDark, -0.14, 0.28, 0.17);
    addBox(rig.torso, 0.08, 0.34, 0.02, leatherDark, 0.14, 0.28, 0.17);
    addBox(rig.torso, 0.5, 0.08, 0.05, leatherDark, 0, -0.38, 0.19);
    addStud(rig.torso, brass, 0, -0.1, 0.205, 0.03, 0.015).rotation.x = Math.PI / 2;
    // tools on the belt
    addBox(rig.torso, 0.1, 0.16, 0.08, leather, 0.26, -0.33, 0.1);
    // smithing hammer in the right hand
    addCyl(rig.handR, 0.03, 0.03, 0.55, wood, 0, 0.2, 0.0, 8);
    addBox(rig.handR, 0.28, 0.16, 0.16, steel, 0, 0.5, 0);
    addBox(rig.handR, 0.06, 0.18, 0.18, std('#3B4252', 0.4, 0.7), 0.16, 0.5, 0);
    rig.armR.rotation.x = -0.35;
    rig.foreR.rotation.x = -0.5;

    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    registerNPC({
      id: 'npc_toren',
      voice: 'toren',
      rig,
      phase: 1.3,
      free: 'L',
      baseL: 0.05,
      baseR: -0.35,
      extra: (t, r, busy) => {
        if (busy) return; // stops hammering when you come close
        // hammer the anvil: raise -> strike -> recover (3.4 s loop)
        const p = (t % 3.4) / 3.4;
        if (p < 0.55) {
          const q = p / 0.55;
          r.armR.rotation.x = -0.35 - q * 1.5;
          r.foreR.rotation.x = -0.5 - q * 0.6;
          r.torso.rotation.x = -0.05 * q;
        } else if (p < 0.65) {
          const q = (p - 0.55) / 0.1;
          r.armR.rotation.x = -1.85 + q * 2.0;
          r.foreR.rotation.x = -1.1 + q * 0.7;
          r.torso.rotation.x = 0.16 * q;
        } else {
          const q = (p - 0.65) / 0.35;
          r.armR.rotation.x = 0.15 - q * 0.5;
          r.foreR.rotation.x = -0.4 - q * 0.1;
          r.torso.rotation.x = 0.16 * (1 - q);
        }
      },
    });

    npcs.push({
      id: 'npc_toren',
      type: 'toren',
      name: 'Toren',
      title: 'Master Blacksmith',
      position: { x, y: 0, z },
      rotation: 0,
      dialogue: [
        'Well met, warrior! I am Toren, smith of the lost realm.',
        'Bring me 2 Iron and 3 Wood, and I can reinforce your gear with a sturdy Viking Shield.',
        'Strike the iron veins near the rocky foothills to gather ore.',
      ],
      mesh: rig.root,
    });
  }

  // 3. Alden - Wandering Merchant by the tent
  function spawnMerchant(x: number, z: number) {
    const coat = std('#6B4423', 0.65, 0.05);
    const rig = makeFigure({
      skin: '#E2A87F',
      torso: coat,
      pants: '#4B3A2A',
      boots: '#3A2616',
      sleeve: '#6B4423',
      bracer: '#4A2E1D',
      glove: '#2B1A10',
      face: makeFaceTexture('human', { skin: '#E2A87F', beard: 'moustache', beardColor: '#4A3020', iris: '#2F5D3A' }),
    });
    addShortHair(rig.head, '#4A3020');
    // wide-brim hat with red band
    const hatMat = std('#3F2A18', 0.7, 0.03);
    addCyl(rig.head, 0.4, 0.4, 0.035, hatMat, 0, 0.2, 0, 16);
    addCyl(rig.head, 0.2, 0.22, 0.22, hatMat, 0, 0.32, 0, 12);
    addCyl(rig.head, 0.225, 0.225, 0.05, std('#932029', 0.5, 0.1), 0, 0.24, 0, 12);
    // long coat skirt + lapels
    addBox(rig.body, 0.6, 0.4, 0.36, coat, 0, -0.42, 0);
    addBox(rig.torso, 0.1, 0.5, 0.02, std('#8B5A2B', 0.6, 0.05), -0.12, 0.02, 0.17);
    addBox(rig.torso, 0.1, 0.5, 0.02, std('#8B5A2B', 0.6, 0.05), 0.12, 0.02, 0.17);
    [-0.05, 0.1, 0.25].forEach((by) => addStud(rig.torso, brass, 0, by - 0.1, 0.19, 0.025, 0.015).rotation.x = Math.PI / 2);
    // coin pouch
    addBox(rig.torso, 0.12, 0.14, 0.08, leather, 0.24, -0.33, 0.1);
    addSphere(rig.torso, 0.03, brass, 0.24, -0.25, 0.14);
    // big travel pack with bedroll & pots
    addBox(rig.torso, 0.5, 0.6, 0.26, leather, 0, 0.02, -0.28);
    addCyl(rig.torso, 0.09, 0.09, 0.56, leatherDark, 0, 0.36, -0.28, 12).rotation.z = Math.PI / 2;
    addCyl(rig.torso, 0.06, 0.06, 0.09, steel, 0.2, -0.32, -0.45, 10);
    addCyl(rig.torso, 0.05, 0.05, 0.08, brass, -0.18, -0.3, -0.45, 10);
    // lantern in the left hand
    addCyl(rig.handL, 0.045, 0.045, 0.14, brass, 0, -0.18, 0.02, 8);
    addSphere(rig.handL, 0.045, new THREE.MeshBasicMaterial({ color: '#FEF08A' }), 0, -0.18, 0.02);
    addBox(rig.handL, 0.02, 0.12, 0.02, brass, 0, -0.07, 0);

    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    registerNPC({
      id: 'npc_merchant',
      voice: 'merchant',
      rig,
      phase: 2.1,
      free: 'R',
      baseL: -0.15,
      baseR: -0.05,
      extra: (t, r) => {
        r.armL.rotation.x = -0.15 + Math.sin(t * 1.4) * 0.1; // swinging lantern
        r.body.rotation.y = Math.sin(t * 0.6) * 0.05;
      },
    });

    npcs.push({
      id: 'npc_merchant',
      type: 'merchant',
      name: 'Alden',
      title: 'Wandering Merchant',
      position: { x, y: 0, z },
      rotation: 0,
      dialogue: [
        'Welcome, traveler! Rare goods from distant shores for trade.',
        'I have fresh Health Potions, Bomb satchels, and bundles of feathered Arrows.',
        'Smash barrels and crates around the glade to find gold and supplies!',
      ],
      mesh: rig.root,
    });
  }

  // 4. Gareth - armoured Outpost Sentinel
  function spawnGuard(x: number, z: number) {
    const plate = new THREE.MeshStandardMaterial({ color: '#64748B', roughness: 0.3, metalness: 0.8 });
    const rig = makeFigure({
      skin: '#E0A57C',
      torso: plate,
      pants: '#3B4252',
      boots: '#3A3F4B',
      sleeve: '#64748B',
      bracer: '#475569',
      glove: '#2B2F38',
      face: makeFaceTexture('human', { skin: '#E0A57C', beard: 'moustache', beardColor: '#3A2A1E', iris: '#4A5A6A' }),
    });
    // great helm: cap, back, cheek plates and nasal bar - the face stays visible
    addBox(rig.head, 0.44, 0.14, 0.42, steel, 0, 0.2, -0.01);
    addBox(rig.head, 0.44, 0.4, 0.1, steel, 0, 0.0, -0.21);
    [-1, 1].forEach((sx) => addBox(rig.head, 0.05, 0.3, 0.36, steel, sx * 0.215, 0.04, -0.0));
    addBox(rig.head, 0.05, 0.22, 0.04, steel, 0, 0.06, 0.2);
    addBox(rig.head, 0.4, 0.04, 0.04, brass, 0, 0.13, 0.2);
    addBox(rig.head, 0.06, 0.12, 0.3, std('#932029', 0.5, 0.1), 0, 0.33, -0.02); // crest
    // chest plate details & tabard
    addBox(rig.torso, 0.5, 0.5, 0.04, steel, 0, 0.0, 0.17);
    addBox(rig.torso, 0.18, 0.5, 0.045, std('#1E3A5F', 0.6, 0.05), 0, -0.1, 0.19);
    addStud(rig.torso, brass, 0, 0.08, 0.215, 0.05, 0.02).rotation.x = Math.PI / 2;
    // pauldrons
    addBox(rig.armL, 0.2, 0.12, 0.2, steel, 0, 0.03, 0);
    addBox(rig.armR, 0.2, 0.12, 0.2, steel, 0, 0.03, 0);
    // greaves
    [rig.legL, rig.legR].forEach((leg) => addBox(leg, 0.24, 0.3, 0.06, steel, 0, -0.46, 0.13));
    // spear in the right hand
    addCyl(rig.handR, 0.03, 0.03, 2.4, wood, 0, 0.65, 0.0, 8);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.3, 4), steel);
    tip.position.set(0, 1.97, 0);
    rig.handR.add(tip);
    // round shield on the left forearm
    const shield = addCyl(rig.foreL, 0.3, 0.3, 0.05, steel, -0.12, -0.1, 0.0, 20);
    shield.rotation.z = Math.PI / 2;
    addStud(rig.foreL, brass, -0.155, -0.1, 0, 0.07, 0.04).rotation.z = Math.PI / 2;
    rig.armR.rotation.x = -0.1;

    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    registerNPC({
      id: 'npc_guard',
      voice: 'guard',
      rig,
      phase: 3.2,
      free: null,
      baseL: -0.1,
      baseR: -0.1,
      extra: (t, r, busy) => {
        // stands at attention, occasionally shifts a foot
        const p = (t + 1.5) % 7;
        if (!busy && p < 0.5) r.legR.rotation.x = -Math.sin((p / 0.5) * Math.PI) * 0.45;
      },
    });

    npcs.push({
      id: 'npc_guard',
      type: 'guard',
      name: 'Gareth',
      title: 'Outpost Sentinel',
      position: { x, y: 0, z },
      rotation: 0,
      dialogue: [
        'Halt, traveler! The road to the north is perilous.',
        'Prowling wolves and bandit rogues have infested the valley.',
        'Stay near the campfire light at night. Good hunting, Seeker.',
      ],
      mesh: rig.root,
    });
  }

  // Spawns
  spawnMara(-4, 9); // Near campfire
  spawnToren(18, 0); // Outside Blacksmith forge
  spawnMerchant(-10, 10); // Outside Traveler tent
  spawnGuard(-17, -5); // Guarding outpost entrance

  npcs.forEach((n) => n.mesh && enableShadows(n.mesh));

  let clock = 0;
  const update = (delta: number, playerPos: THREE.Vector3) => {
    clock += delta;
    anims.forEach((a) => animateNPC(a, clock, delta, playerPos));
    // Face player if nearby
    npcs.forEach((npc) => {
      const dx = playerPos.x - npc.position.x;
      const dz = playerPos.z - npc.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < 5.0 && npc.mesh) {
        const target = Math.atan2(dx, dz);
        let diff = target - npc.mesh.rotation.y;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        npc.mesh.rotation.y += diff * Math.min(1, delta * 6);
      }
    });
  };

  const getNearbyNPC = (playerPos: THREE.Vector3, range = 2.6): NPCData | null => {
    for (const npc of npcs) {
      const dx = playerPos.x - npc.position.x;
      const dz = playerPos.z - npc.position.z;
      if (Math.sqrt(dx * dx + dz * dz) <= range) {
        return npc;
      }
    }
    return null;
  };

  const setTalking = (id: string | null) => {
    talkingId = id;
  };

  return { npcs, update, getNearbyNPC, setTalking };
}
