import * as THREE from 'three';
import { RelicEnemy, RelicEnemyType } from '../types/relic';
import { createMaterials } from '../world/materials';
import { GAME_CONFIG } from '../core/config';
import {
  FigureAnimState,
  addBox,
  addSphere,
  addStud,
  addCyl,
  addHood,
  enableShadows,
  makeFaceTexture,
  makeFigure,
  makeHumanoidAnimator,
  makeRibsTexture,
  std,
} from '../game/character/legoFigures';

export interface RelicEnemiesSystem {
  enemies: RelicEnemy[];
  /** `active` is false while the player is in the Base: enemies stay put and never aggro. */
  update: (delta: number, playerPos: THREE.Vector3, onDamagePlayer: (dmg: number) => void, active?: boolean) => void;
  damageEnemy: (id: string, dmg: number) => { dead: boolean; enemy?: RelicEnemy };
}

export function buildRelicEnemies(scene: THREE.Scene): RelicEnemiesSystem {
  const mats = createMaterials();
  const enemies: RelicEnemy[] = [];

  const matSteel = new THREE.MeshStandardMaterial({ color: '#94A3B8', metalness: 0.85, roughness: 0.25 });
  const matRust = new THREE.MeshStandardMaterial({ color: '#8B6B4A', metalness: 0.7, roughness: 0.5 });
  const matLeather = std('#54341B', 0.6, 0.12);
  const matLeatherDark = std('#341E12', 0.45, 0.2);
  const matBone = std('#E6DFC9', 0.45, 0.05);
  const matBrass = new THREE.MeshStandardMaterial({ color: '#D4AF37', roughness: 0.25, metalness: 0.75 });
  const matCrystalBlue = new THREE.MeshBasicMaterial({ color: '#38BDF8' });

  type Anim = (delta: number, s: FigureAnimState) => void;
  const attach = (group: THREE.Object3D, anim: Anim) => {
    group.userData.anim = anim;
  };

  // 1. Spawning Wolf (blocky Lego dire wolf)
  function spawnWolf(id: string, x: number, z: number) {
    const group = new THREE.Group();
    group.position.set(x, 0, z);

    const fur = std('#566274', 0.8, 0.02);
    const furLight = std('#8B97A8', 0.8, 0.02);
    const furDark = std('#3B4452', 0.8, 0.02);

    const body = new THREE.Group();
    group.add(body);
    addBox(body, 0.5, 0.5, 1.1, fur, 0, 0.55, 0);
    addBox(body, 0.4, 0.14, 0.9, furLight, 0, 0.3, 0.02); // belly
    addBox(body, 0.52, 0.18, 0.4, furDark, 0, 0.74, 0.28); // mane / shoulders
    [-0.3, -0.1, 0.1, 0.3].forEach((zz) => addStud(body, furDark, 0, 0.81, zz, 0.05, 0.03));

    // head (face texture is painted on the front side: red eyes, nose, fangs)
    const headFur = std('#566274', 0.8, 0.02);
    const faceMat = new THREE.MeshStandardMaterial({ map: makeFaceTexture('wolf'), roughness: 0.6 });
    const head = new THREE.Group();
    head.position.set(0, 0.8, 0.62);
    body.add(head);
    addBox(head, 0.38, 0.34, 0.38, [headFur, headFur, headFur, headFur, faceMat, headFur], 0, 0, 0);
    addBox(head, 0.2, 0.1, 0.1, furLight, 0, -0.14, 0.22); // muzzle block
    addBox(head, 0.12, 0.07, 0.06, std('#0B0B0D', 0.3, 0.3), 0, -0.07, 0.27);
    [-0.12, 0.12].forEach((ex) => {
      addBox(head, 0.1, 0.16, 0.06, furDark, ex, 0.25, -0.02);
      addStud(head, furDark, ex, 0.34, -0.02, 0.03, 0.02);
    });
    addBox(body, 0.3, 0.3, 0.3, fur, 0, 0.68, 0.45); // neck

    // tail (3 stepped segments)
    const tail = new THREE.Group();
    tail.position.set(0, 0.66, -0.58);
    body.add(tail);
    addBox(tail, 0.14, 0.14, 0.3, fur, 0, 0.04, -0.1).rotation.x = 0.5;
    addBox(tail, 0.12, 0.12, 0.26, furDark, 0, 0.18, -0.32).rotation.x = 0.8;
    addBox(tail, 0.1, 0.1, 0.2, furLight, 0, 0.34, -0.45).rotation.x = 1.0;

    // 4 legs on pivots
    const legs: THREE.Group[] = [];
    [[-0.2, -0.36], [0.2, -0.36], [-0.2, 0.36], [0.2, 0.36]].forEach(([lx, lz]) => {
      const leg = new THREE.Group();
      leg.position.set(lx, 0.5, lz);
      addBox(leg, 0.14, 0.5, 0.14, fur, 0, -0.25, 0);
      addBox(leg, 0.16, 0.08, 0.2, furDark, 0, -0.46, 0.03);
      group.add(leg);
      legs.push(leg);
    });

    enableShadows(group);
    scene.add(group);

    let t = Math.random() * 6;
    attach(group, (delta, st) => {
      t += delta;
      const sw = st.moving ? Math.sin(t * 12) * 0.7 : 0;
      legs[0].rotation.x = sw;
      legs[3].rotation.x = sw;
      legs[1].rotation.x = -sw;
      legs[2].rotation.x = -sw;
      body.position.y = st.moving ? Math.abs(Math.sin(t * 12)) * 0.05 : Math.sin(t * 2) * 0.01;
      tail.rotation.y = Math.sin(t * (st.moving ? 10 : 3)) * 0.35;
      head.rotation.x = st.attacking ? Math.sin(t * 14) * 0.35 : 0;
    });

    enemies.push({
      id,
      type: 'wolf',
      name: 'Dire Wolf',
      position: { x, y: 0, z },
      rotation: 0,
      health: 35,
      maxHealth: 35,
      attackPower: 10,
      speed: 4.8,
      attackRange: 1.6,
      state: 'patrol',
      mesh: group,
      attackCooldown: 0,
      patrolCenter: { x, z },
    });
  }

  // 2. Spawning Bandit Rogue (masked, hooded, twin daggers)
  function spawnBandit(id: string, x: number, z: number) {
    const rig = makeFigure({
      skin: '#D99A6C',
      torso: matLeather,
      pants: '#2F2A2A',
      boots: '#2B1A10',
      sleeve: '#3A2A22',
      bracer: '#241812',
      glove: '#1A110C',
      face: makeFaceTexture('bandit', { skin: '#D99A6C', iris: '#2F2F2F', maskColor: '#7F1D1D', scar: true }),
    });
    addHood(rig.head, '#7F1D1D');
    // crossed belts, buckles, pouch
    const belt = matLeatherDark;
    const b1 = addBox(rig.torso, 0.1, 0.66, 0.035, belt, 0, 0, 0.172);
    b1.rotation.z = 0.6;
    const b2 = addBox(rig.torso, 0.1, 0.66, 0.035, belt, 0, 0, 0.172);
    b2.rotation.z = -0.6;
    addStud(rig.torso, matBrass, 0, 0, 0.2, 0.03, 0.02).rotation.x = Math.PI / 2;
    addBox(rig.torso, 0.14, 0.16, 0.08, matLeather, 0.22, -0.33, 0.1);
    // torn red cloth hanging at the hip
    addBox(rig.torso, 0.16, 0.34, 0.03, std('#7F1D1D', 0.6, 0.05), -0.18, -0.45, 0.17);
    // shoulder scrap
    addBox(rig.armL, 0.18, 0.1, 0.18, matLeatherDark, 0, 0.04, 0);
    // twin daggers pointing forward
    [rig.handL, rig.handR].forEach((h) => {
      const d = new THREE.Group();
      d.rotation.x = Math.PI / 2;
      d.position.set(0, -0.02, 0.06);
      addBox(d, 0.05, 0.34, 0.018, matSteel, 0, 0.22, 0);
      addBox(d, 0.14, 0.035, 0.04, matBrass, 0, 0.04, 0);
      addBox(d, 0.035, 0.12, 0.035, matLeatherDark, 0, -0.04, 0);
      h.add(d);
    });
    enableShadows(rig.root);
    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    attach(rig.root, makeHumanoidAnimator(rig, { stride: 0.8, speed: 11 }));

    enemies.push({
      id,
      type: 'bandit',
      name: 'Valley Bandit',
      position: { x, y: 0, z },
      rotation: 0,
      health: 45,
      maxHealth: 45,
      attackPower: 14,
      speed: 3.8,
      attackRange: 1.8,
      state: 'patrol',
      mesh: rig.root,
      attackCooldown: 0,
      patrolCenter: { x, z },
    });
  }

  // 3. Spawning Skeleton Swordsman
  function spawnSkeleton(id: string, x: number, z: number) {
    const ribs = new THREE.MeshStandardMaterial({ map: makeRibsTexture(), roughness: 0.5 });
    const rig = makeFigure({
      skin: '#E6DFC9',
      torso: [matBone, matBone, matBone, matBone, ribs, ribs],
      pants: '#D8D1BC',
      boots: '#CFC8B2',
      sleeve: null,
      bracer: '#CFC8B2',
      glove: '#E6DFC9',
      armW: 0.62,
      legW: 0.7,
      torsoW: 0.88,
      face: makeFaceTexture('skull'),
    });
    // tattered loincloth + rusty belt
    addBox(rig.torso, 0.4, 0.3, 0.03, std('#4B3A2A', 0.8, 0.02), 0, -0.45, 0.17);
    addBox(rig.torso, 0.1, 0.12, 0.06, matRust, 0, -0.25, 0.19);
    // spine knobs on the shoulders
    [-1, 1].forEach((sx) => addSphere(rig.torso, 0.07, matBone, sx * 0.27, 0.27, 0));
    // rusty sword
    const sword = new THREE.Group();
    sword.rotation.x = Math.PI / 2;
    sword.position.set(0, -0.02, 0.05);
    addBox(sword, 0.08, 0.62, 0.025, matRust, 0, 0.36, 0);
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.056, 0.14, 4), matRust);
    tip.position.y = 0.74;
    tip.rotation.y = Math.PI / 4;
    sword.add(tip);
    addBox(sword, 0.26, 0.05, 0.06, matLeatherDark, 0, 0.04, 0);
    addBox(sword, 0.04, 0.16, 0.04, matLeatherDark, 0, -0.06, 0);
    rig.handR.add(sword);
    rig.armR.rotation.x = -0.4;
    // round wooden shield on the left forearm
    const sh = addCyl(rig.foreL, 0.3, 0.3, 0.05, matLeather, -0.12, -0.1, 0.0, 20);
    sh.rotation.z = Math.PI / 2;
    addStud(rig.foreL, matRust, -0.155, -0.1, 0, 0.07, 0.04).rotation.z = Math.PI / 2;
    addBox(rig.foreL, 0.03, 0.56, 0.08, matLeatherDark, -0.14, -0.1, 0);
    enableShadows(rig.root);
    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    attach(rig.root, makeHumanoidAnimator(rig, { stride: 0.7, speed: 9 }));

    enemies.push({
      id,
      type: 'skeleton',
      name: 'Skeleton Warrior',
      position: { x, y: 0, z },
      rotation: 0,
      health: 50,
      maxHealth: 50,
      attackPower: 15,
      speed: 3.2,
      attackRange: 2.0,
      state: 'patrol',
      mesh: rig.root,
      attackCooldown: 0,
      patrolCenter: { x, z },
    });
  }

  // 4. Spawning Orc Brute
  function spawnOrc(id: string, x: number, z: number) {
    const rig = makeFigure({
      scale: 1.22,
      skin: '#4F7A3F',
      torso: matLeather,
      pants: '#3A2A22',
      boots: '#2B1A10',
      sleeve: null, // bare green arms
      bracer: '#475569',
      glove: '#2B1A10',
      armW: 1.45,
      legW: 1.2,
      torsoW: 1.3,
      face: makeFaceTexture('orc'),
    });
    // black mohawk
    const hair = std('#15110E', 0.5, 0.05);
    addBox(rig.head, 0.1, 0.12, 0.4, hair, 0, 0.24, -0.02);
    // spiked steel pauldrons
    [rig.armL, rig.armR].forEach((arm, i) => {
      addBox(arm, 0.26, 0.12, 0.26, matSteel, 0, 0.04, 0);
      [-0.06, 0.06].forEach((sx) => {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.16, 4), matSteel);
        spike.position.set(sx + (i === 0 ? -0.04 : 0.04), 0.16, 0);
        arm.add(spike);
      });
    });
    // iron plates on the chest, skull buckle, loincloth
    addBox(rig.torso, 0.62, 0.3, 0.04, matSteel, 0, 0.12, 0.17);
    addBox(rig.torso, 0.12, 0.12, 0.06, matBone, 0, -0.25, 0.2);
    addBox(rig.torso, 0.3, 0.34, 0.03, std('#7F1D1D', 0.6, 0.05), 0, -0.46, 0.17);
    // battleaxe in the right hand
    const axe = new THREE.Group();
    axe.position.set(0, 0, 0.0);
    addCyl(axe, 0.035, 0.035, 1.5, mats.woodLog, 0, 0.45, 0, 8);
    addBox(axe, 0.5, 0.34, 0.06, matSteel, 0.2, 1.05, 0);
    addBox(axe, 0.5, 0.34, 0.06, matSteel, -0.2, 1.05, 0);
    addBox(axe, 0.08, 0.5, 0.1, matSteel, 0, 1.05, 0);
    rig.handR.add(axe);
    rig.armR.rotation.x = -0.3;
    enableShadows(rig.root);
    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    attach(rig.root, makeHumanoidAnimator(rig, { stride: 0.55, speed: 7 }));

    enemies.push({
      id,
      type: 'orc',
      name: 'Orc Warlord',
      position: { x, y: 0, z },
      rotation: 0,
      health: 95,
      maxHealth: 95,
      attackPower: 22,
      speed: 2.8,
      attackRange: 2.2,
      state: 'patrol',
      mesh: rig.root,
      attackCooldown: 0,
      patrolCenter: { x, z },
    });
  }

  // 5. Spawning Dungeon Guardian (Boss Titan, stone Lego golem)
  function spawnDungeonGuardian(id: string, x: number, z: number) {
    const stone = std('#475569', 0.8, 0.05);
    const stoneDark = std('#334155', 0.85, 0.05);
    const rig = makeFigure({
      scale: 2.05,
      skin: '#475569',
      torso: stone,
      pants: '#334155',
      boots: '#2B3646',
      sleeve: '#475569',
      bracer: '#334155',
      glove: '#2B3646',
      armW: 1.5,
      legW: 1.35,
      torsoW: 1.45,
      face: makeFaceTexture('golem'),
    });
    // arcane core + runes on the chest
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.14, 1), matCrystalBlue);
    core.position.set(0, 0.04, 0.22);
    rig.torso.add(core);
    [-0.2, 0.2].forEach((rx) => addBox(rig.torso, 0.03, 0.34, 0.02, matCrystalBlue, rx, 0.04, 0.17));
    addBox(rig.torso, 0.4, 0.03, 0.02, matCrystalBlue, 0, 0.24, 0.17);
    addBox(rig.torso, 0.4, 0.03, 0.02, matCrystalBlue, 0, -0.16, 0.17);
    const coreLight = new THREE.PointLight('#38BDF8', 3.0, 10);
    coreLight.position.set(0, 0.04, 0.5);
    rig.torso.add(coreLight);
    // boulder shoulders with crystal spikes
    [rig.armL, rig.armR].forEach((arm, i) => {
      addBox(arm, 0.28, 0.2, 0.28, stoneDark, 0, 0.04, 0);
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.3, 4), matCrystalBlue);
      spike.position.set(i === 0 ? -0.06 : 0.06, 0.26, 0);
      arm.add(spike);
    });
    // horns
    [-1, 1].forEach((sx) => {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.34, 4), matCrystalBlue);
      horn.position.set(sx * 0.17, 0.33, 0);
      horn.rotation.z = -sx * 0.4;
      rig.head.add(horn);
    });
    addBox(rig.head, 0.44, 0.1, 0.42, stoneDark, 0, 0.21, -0.01); // brow slab
    // crystal knuckles
    [rig.handL, rig.handR].forEach((h) => addBox(h, 0.16, 0.14, 0.16, stoneDark, 0, -0.04, 0));
    enableShadows(rig.root);
    rig.root.position.set(x, 0, z);
    scene.add(rig.root);
    attach(rig.root, makeHumanoidAnimator(rig, { stride: 0.42, speed: 5 }));

    enemies.push({
      id,
      type: 'dungeon_guardian',
      name: 'Dungeon Guardian (Titan Boss)',
      position: { x, y: 0, z },
      rotation: 0,
      health: 220,
      maxHealth: 220,
      attackPower: 32,
      speed: 2.2,
      attackRange: 2.8,
      state: 'idle',
      mesh: rig.root,
      attackCooldown: 0,
      patrolCenter: { x, z },
    });
  }

  // Spawns: ALL enemies live in Stage 1, beyond the gate (north, -z). The Base is a safe hub.
  // Layout runs north from the gate in increasing difficulty, ending at the boss.
  spawnWolf('wolf_1', -24, -49);
  spawnWolf('wolf_2', -19, -53);

  spawnBandit('bandit_1', -30, -61);
  spawnBandit('bandit_2', -18, -64);

  spawnSkeleton('skel_1', -27, -71);
  spawnSkeleton('skel_2', -15, -73);

  spawnOrc('orc_1', -22, -78);

  // The Dungeon Guardian boss waits at the far end of Stage 1.
  spawnDungeonGuardian('boss_guardian', -24, -85);

  const update = (delta: number, playerPos: THREE.Vector3, onDamagePlayer: (dmg: number) => void, active = true) => {
    enemies.forEach((enemy) => {
      if (enemy.state === 'dead' || enemy.health <= 0) return;

      if (enemy.attackCooldown > 0) {
        enemy.attackCooldown -= delta;
      }

      const dx = playerPos.x - enemy.position.x;
      const dz = playerPos.z - enemy.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      const aggroRadius = enemy.type === 'dungeon_guardian' ? 18 : 14;
      let moving = false;

      if (active && dist < aggroRadius) {
        enemy.rotation = Math.atan2(dx, dz);
        enemy.mesh.rotation.y = enemy.rotation;

        if (dist > enemy.attackRange) {
          const moveX = (dx / dist) * enemy.speed * delta;
          const moveZ = (dz / dist) * enemy.speed * delta;
          enemy.position.x += moveX;
          enemy.position.z = Math.min(enemy.position.z + moveZ, GAME_CONFIG.WORLD.ENEMY_LIMIT_Z);
          enemy.mesh.position.set(enemy.position.x, 0, enemy.position.z);
          enemy.state = 'chase';
          moving = true;
        } else {
          enemy.state = 'attack';
          if (enemy.attackCooldown <= 0) {
            enemy.attackCooldown = enemy.type === 'dungeon_guardian' ? 2.6 : 1.7;
            onDamagePlayer(enemy.attackPower);

            // Punch lunging animation
            enemy.mesh.position.y = 0.25;
            setTimeout(() => {
              if (enemy.mesh) enemy.mesh.position.y = 0;
            }, 180);
          }
        }
      } else {
        // Patrol
        enemy.state = 'patrol';
        const patrolDx = enemy.patrolCenter.x - enemy.position.x;
        const patrolDz = enemy.patrolCenter.z - enemy.position.z;
        const patrolDist = Math.sqrt(patrolDx * patrolDx + patrolDz * patrolDz);
        if (patrolDist > 1.0) {
          enemy.position.x += (patrolDx / patrolDist) * 1.0 * delta;
          enemy.position.z += (patrolDz / patrolDist) * 1.0 * delta;
          enemy.mesh.position.set(enemy.position.x, 0, enemy.position.z);
          enemy.mesh.rotation.y = Math.atan2(patrolDx, patrolDz);
          moving = true;
        }
      }

      enemy.mesh.userData.anim?.(delta, { moving, attacking: enemy.state === 'attack' });
    });
  };

  const damageEnemy = (id: string, dmg: number) => {
    const enemy = enemies.find((e) => e.id === id);
    if (!enemy || enemy.health <= 0) return { dead: false };

    enemy.health = Math.max(0, enemy.health - dmg);

    if (enemy.mesh) {
      enemy.mesh.position.y = 0.3;
      setTimeout(() => {
        if (enemy.mesh) enemy.mesh.position.y = 0;
      }, 120);
    }

    if (enemy.health <= 0) {
      enemy.state = 'dead';
      if (enemy.mesh) {
        enemy.mesh.rotation.x = Math.PI / 2;
        enemy.mesh.position.y = 0.2;
        setTimeout(() => {
          scene.remove(enemy.mesh);
        }, 3000);
      }
      return { dead: true, enemy };
    }

    return { dead: false, enemy };
  };

  return { enemies, update, damageEnemy };
}
